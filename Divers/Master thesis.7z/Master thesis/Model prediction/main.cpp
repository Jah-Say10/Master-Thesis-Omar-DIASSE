#include <iostream>
#include <cmath>

void predictBilan(int year);
void predictCompteResultat(int year);

long predictChargeImmobilises(int year);
long predictImmobilisationCorporelle(int year);
long predictImmobilisationIncorporelle(int year);
long predictImmobilisationFinanciere(int year);
long predictTotalActifImmobilises(int year);
long calculateTotalActifImmobilises(int year);

long predictStock(int year);
long predictclients(int year);
long predictAutresCreances(int year);
long predictTotalActifCirculant(int year);

long predictTresoreriePassif(int year);

long predictTotalActif(int year);
long calculateTotalActif(int year);

long predictCapital();
long predictPrimesReserves(int year);
long predictResultatNet(int year);
long predictPartEntreprise(int year);
long calculatePartEntreprise(int year);
long predictPartMinotaire(int year);
long predictTotalCapitauxPropres(int year);
long calculateTotalCapitauxPropres(int year);

long predictInteretDiffere(int year);
long predictEmpruntsDettesFinancieres(int year);
long predictProvisionFinanciere(int year);
long predictTotalDettesFinancieres(int year);
long calculateTotalDettesFinancieres(int year);

long predictDettesCirculant(int year);

long predictFournisseursExploitation(int year);
long predictAutresDettes(int year);
long predictTotalPassifCirculant(int year);
long calculateTotalPassifCirculant(int year);

long predictTotalTresoreriePassif(int year);

long predictTotalPassif(int year);
long calculateTotalPassif(int year);

////////////////////////////////////////
////////////////////////////////////////
////////////////////////////////////////

long predictChiffreDAffaires(int year);

int main()
{
    std::cout << "MASTER THESIS !!!" << std::endl;

    int year = 2025;
    std::cout << "Donnez l'annee : ";
    std::cin >> year;

    // predictBilan(year);
    predictCompteResultat(year);

    return 0;
}

void predictBilan(int year)
{
    std::cout << "Prediction bilan = " << year << std::endl << std::endl;

    std::cout << "Charges immobolisees = " << predictChargeImmobilises(year) << std::endl;
    std::cout << "Immobilisation incorporelle = " << predictImmobilisationCorporelle(year) << std::endl;
    std::cout << "Immobilisation corporelle = " << predictImmobilisationIncorporelle(year) << std::endl;
    std::cout << "Immobilisation financiere = " << predictImmobilisationFinanciere(year) << std::endl;
    std::cout << "Total actif immobilises (p) = " << predictTotalActifImmobilises(year) << std::endl;
    std::cout << "Total actif immobilises (c) = " << calculateTotalActifImmobilises(year) << std::endl;
    
    std::cout << std::endl;
    std::cout << "Stock = " << predictStock(year) << std::endl;
    std::cout << "Clients = " << predictclients(year) << std::endl;
    std::cout << "Autres creances = " << predictAutresCreances(year) << std::endl;
    std::cout << "Total actif circulant = " << predictTotalActifCirculant(year) << std::endl;

    std::cout << std::endl;
    std::cout << "Total tresorerie passif = " << predictTresoreriePassif(year) << std::endl;

    std::cout << std::endl;
    std::cout << "Total actif (p) = " << predictTotalActif(year) << std::endl;
    std::cout << "Total actif (c) = " << calculateTotalActif(year) << std::endl;

    std::cout << std::endl;
    std::cout << "Capital = " << predictCapital() << std::endl;
    std::cout << "Primes et reserves = " << predictPrimesReserves(year) << std::endl;
    std::cout << "Resultat net = " << predictResultatNet(year) << std::endl;
    std::cout << "Part de l'entreprise (p) = " << predictPartEntreprise(year) << std::endl;
    std::cout << "Part de l'entreprise (c) = " << calculatePartEntreprise(year) << std::endl;
    std::cout << "Part des minoritaires = " << predictPartMinotaire(year) << std::endl;
    std::cout << "Total capitaux propes (p) = " << predictTotalCapitauxPropres(year) << std::endl;
    std::cout << "Total capitaux propes (c) = " << calculateTotalCapitauxPropres(year) << std::endl;

    std::cout << std::endl;
    std::cout << "Interet differe = " << predictInteretDiffere(year) << std::endl;
    std::cout << "Emprunts et dettes financieres = " << predictEmpruntsDettesFinancieres(year) << std::endl;
    std::cout << "Provisions financieres = " << predictProvisionFinanciere(year) << std::endl;
    std::cout << "Total dettes financieres (p) = " << predictTotalDettesFinancieres(year) << std::endl;
    std::cout << "Total dettes financieres (c) = " << calculateTotalDettesFinancieres(year) << std::endl;

    std::cout << std::endl;
    std::cout << "Dettes circulants = " << predictDettesCirculant(year) << std::endl;

    std::cout << std::endl;
    std::cout << "Fournisseur d'exploitation = " << predictFournisseursExploitation(year) << std::endl;
    std::cout << "Autres dettes = " << predictAutresDettes(year) << std::endl;
    std::cout << "Total Passif circulant (p) = " << predictTotalPassifCirculant(year) << std::endl;
    std::cout << "Total Passif circulant (c) = " << calculateTotalPassifCirculant(year) << std::endl;

    std::cout << std::endl;
    std::cout << "Total tresorerie passif = " << predictTotalTresoreriePassif(year) << std::endl;

    std::cout << std::endl;
    std::cout << "Total passif (p) = " << predictTotalPassif(year) << std::endl;
    std::cout << "Total passif (c) = " << calculateTotalPassif(year) << std::endl;
}

void predictCompteResultat(int year)
{
    std::cout << "Prediction compte de resultat = " << year << std::endl << std::endl;

    std::cout << "Chiffre d'affaire = " << predictChiffreDAffaires(year) << std::endl;
}

long predictChargeImmobilises(int year)
{
    float const COEFFICIENT = -91.15810277f;
    float const INTERCEPT = 183827.60079051f;

    return COEFFICIENT * year + INTERCEPT;
}

long predictImmobilisationCorporelle(int year)
{
    float const COEFFICIENT0 = 0.00000000e+00f;
    float const COEFFICIENT1 = -4.17210459e+06f;
    float const COEFFICIENT2 = 1.04126033e+03f;
    float const INTERCEPT = 4.17918018e+09f;

    return COEFFICIENT0 + COEFFICIENT1 * year + COEFFICIENT2 * pow(year, 2) + INTERCEPT;
}

long predictImmobilisationIncorporelle(int year)
{
    float const COEFFICIENT = 27954.21936759f;
    float const INTERCEPT = -55739313.40316205f;

    return COEFFICIENT * year + INTERCEPT;
}

long predictImmobilisationFinanciere(int year)
{
    float const COEFFICIENT0 = 0.00000000e+00f;
    float const COEFFICIENT1 = -2.33299917e+06f;
    float const COEFFICIENT2 = 5.83074788e+02f;
    float const INTERCEPT = 2.33370722e+09f;

    return COEFFICIENT0 + (COEFFICIENT1 * year) + (COEFFICIENT2 * pow(year, 2)) + INTERCEPT;
}

long predictTotalActifImmobilises(int year)
{
    float const COEFFICIENT0 = 0.00000000e+00f;
    float const COEFFICIENT1 = -7.51855857e+06f;
    float const COEFFICIENT2 = 1.88373735e+03f;
    float const INTERCEPT = 7.50236233e+09f;

    return COEFFICIENT0 + (COEFFICIENT1 * year) + (COEFFICIENT2 * pow(year, 2)) + INTERCEPT;
}

long calculateTotalActifImmobilises(int year)
{
    return predictChargeImmobilises(year) + predictImmobilisationCorporelle(year) + predictImmobilisationIncorporelle(year) + predictImmobilisationFinanciere(year);
}

long predictStock(int year)
{
    float const COEFFICIENT = 712.7826087f;
    float const INTERCEPT = -1421586.91304348f;

    return COEFFICIENT * year + INTERCEPT;  
}

long predictclients(int year)
{
    float const COEFFICIENT = 5457.0958498f;
    float const INTERCEPT = -10873906.50988142f;

    return COEFFICIENT * year + INTERCEPT;  
}

long predictAutresCreances(int year)
{
    float const COEFFICIENT = 4845.13438735f;
    float const INTERCEPT = -9651379.84980237f;

    return COEFFICIENT * year + INTERCEPT;  
}

long predictTotalActifCirculant(int year)
{
    float const COEFFICIENT = 10955.4812253f;
    float const INTERCEPT = -21827712.99604743f;

    return COEFFICIENT * year + INTERCEPT;  
}

long predictTresoreriePassif(int year)
{
    float const COEFFICIENT = 14159.49604743f;
    float const INTERCEPT = -28288445.93280633f;

    return COEFFICIENT * year + INTERCEPT;  
}

long predictTotalActif(int year)
{
    float const COEFFICIENT0 = 0.00000000e+00f;
    float const COEFFICIENT1 = -8.48790609e+06f;
    float const COEFFICIENT2 = 2.13136925e+03f;
    float const INTERCEPT = 8.4506489e+09f;

    return COEFFICIENT0 + (COEFFICIENT1 * year) + (COEFFICIENT2 * pow(year, 2)) + INTERCEPT;
}

long calculateTotalActif(int year)
{
    return predictTotalActifImmobilises(year) + predictTotalActifCirculant(year) + predictTresoreriePassif(year);
}

long predictCapital()
{
    return 50000;
}

long predictPrimesReserves(int year)
{
    float const COEFFICIENT = 18334.50592885f;
    float const INTERCEPT = -36568454.55731225f;

    return COEFFICIENT * year + INTERCEPT; 
}

long predictResultatNet(int year)
{
    float const COEFFICIENT = 8378.87648221f;
    float const INTERCEPT = -16703707.32411067f;

    return COEFFICIENT * year + INTERCEPT; 
}

long predictPartEntreprise(int year)
{
    float const COEFFICIENT = 25997.8201581f;
    float const INTERCEPT = -51785891.26877471f;

    return COEFFICIENT * year + INTERCEPT; 
}

long calculatePartEntreprise(int year)
{
    return predictCapital() + predictPrimesReserves(year) + predictResultatNet(year);
}

long predictPartMinotaire(int year)
{
    float const COEFFICIENT = 4743.9486166f;
    float const INTERCEPT = -9484598.4743083f;

    return COEFFICIENT * year + INTERCEPT; 
}

long predictTotalCapitauxPropres(int year)
{
    float const COEFFICIENT = 30741.73913043f;
    float const INTERCEPT = -61270428.99999998f;

    return COEFFICIENT * year + INTERCEPT; 
}

long calculateTotalCapitauxPropres(int year)
{
    return predictPartEntreprise(year) + predictPartMinotaire(year);
}

long predictInteretDiffere(int year)
{
    float const COEFFICIENT = 0.0f;
    float const INTERCEPT = 1.0f;

    return COEFFICIENT * year + INTERCEPT; 
}

long predictEmpruntsDettesFinancieres(int year)
{
    float const COEFFICIENT0 = 0.00000000e+00f;
    float const COEFFICIENT1 = -2.93859783e+06;
    float const COEFFICIENT2 = 7.32715472e+02;
    float const INTERCEPT = 2.94636848e+09;

    return COEFFICIENT0 + (COEFFICIENT1 * year) + (COEFFICIENT2 * pow(year, 2)) + INTERCEPT;
}

long predictProvisionFinanciere(int year)
{
    float const COEFFICIENT = 3101.97826087f;
    float const INTERCEPT = -6201771.47826087f;

    return COEFFICIENT * year + INTERCEPT; 
}

long predictTotalDettesFinancieres(int year)
{
    float const COEFFICIENT0 = 0.00000000e+00f;
    float const COEFFICIENT1 = -3.73259256e+06;
    float const COEFFICIENT2 = 9.31203783e+02f;
    float const INTERCEPT = 3.74041078e+09f;

    return COEFFICIENT0 + (COEFFICIENT1 * year) + (COEFFICIENT2 * pow(year, 2)) + INTERCEPT;
}

long calculateTotalDettesFinancieres(int year)
{
    return predictInteretDiffere(year) + predictEmpruntsDettesFinancieres(year) + predictProvisionFinanciere(year);
}

long predictDettesCirculant(int year)
{
    float const COEFFICIENT = 0.0f;
    float const INTERCEPT = 1.0f;

    return COEFFICIENT * year + INTERCEPT;
}

long predictFournisseursExploitation(int year)
{
    float const COEFFICIENT = 0.0f;
    float const INTERCEPT = 1.0f;

    return COEFFICIENT * year + INTERCEPT; 
}

long predictAutresDettes(int year)
{
    float const COEFFICIENT0 = 0.00000000e+00f;
    float const COEFFICIENT1 = -2.40376161e+06f;
    float const COEFFICIENT2 = 6.01928233e+02f;
    float const INTERCEPT = 2.39984768e+09f;

    return COEFFICIENT0 + (COEFFICIENT1 * year) + (COEFFICIENT2 * pow(year, 2)) + INTERCEPT;
}

long predictTotalPassifCirculant(int year)
{
    float const COEFFICIENT0 = 0.00000000e+00f;
    float const COEFFICIENT1 = -4.00030285e+06f;
    float const COEFFICIENT2 = 1.00251237e+03f;
    float const INTERCEPT = 3.99062354e+09f;

    return COEFFICIENT0 + (COEFFICIENT1 * year) + (COEFFICIENT2 * pow(year, 2)) + INTERCEPT;
}

long calculateTotalPassifCirculant(int year)
{
    return predictFournisseursExploitation(year) + predictAutresDettes(year);
}

long predictTotalTresoreriePassif(int year)
{
    float const COEFFICIENT0 = 0.00000000e+00f;
    float const COEFFICIENT1 = -2.9239783e+06f;
    float const COEFFICIENT2 = 7.3007908e+02f;
    float const INTERCEPT = 2.92764355e+09f;

    return COEFFICIENT0 + (COEFFICIENT1 * year) + (COEFFICIENT2 * pow(year, 2)) + INTERCEPT;
}

long predictTotalPassif(int year)
{
    float const COEFFICIENT0 = 0.00000000e+00f;
    float const COEFFICIENT1 = -8.48790609e+06f;
    float const COEFFICIENT2 = 2.13136925e+03f;
    float const INTERCEPT = 8.4506489e+09f;

    return COEFFICIENT0 + (COEFFICIENT1 * year) + (COEFFICIENT2 * pow(year, 2)) + INTERCEPT;
}

long calculateTotalPassif(int year)
{
    return predictTotalCapitauxPropres(year) + predictTotalPassifCirculant(year) + predictTotalTresoreriePassif(year);
}


/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////


long predictChiffreDAffaires(int year)
{
    float const COEFFICIENT = 48578.23616601f;
    float const INTERCEPT = -97034585.22134385f;

    return COEFFICIENT * year + INTERCEPT;    
}