"""
    TODO: intent classification
        List all intents
        get data for intent classification
        build model

    TODO: recognize entity like chiffre d'affaires, annee ...
    TODO: get context to the conversion

"""

from chatbot import Chatbot

c = Chatbot()
c.conversion()