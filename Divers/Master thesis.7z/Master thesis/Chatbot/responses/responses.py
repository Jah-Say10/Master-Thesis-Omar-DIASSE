import re
import random
import math
import spacy
from entities import entities
from entities import definitions
nlp = spacy.load("en_core_web_sm")
import sys
sys.path.append("../backend")
from bilan import Bilan
from compte_resultat import CompteResulat
from flux_tresorerie import FluxTresorerie

bilan = Bilan()
compte_resultat = CompteResulat()
flux_tresorerie = FluxTresorerie()

def entities_recognition(question):

    found_entities_elem = []
    found_entities_date = []
    found_entities_vals = []

    # For financial statement elements entity
    for key, entities_synomyms in entities.items():

        if key.lower() in question:
            found_entities_elem.append(key)
            continue

        for synonym in entities_synomyms:
            if synonym.lower() in question:
                found_entities_elem.append(key)
                break

    # For year elements entity
    doc = nlp(question)
    for ent in doc.ents:
        if ent.label_ == "DATE":
            regex_for_number = re.findall("\d{4}|\d{2}|\d{1}", ent.text)
            # check the lenght in case of get when we may not have value date
            for val in regex_for_number:
                if (int(val) > 2000 and int(val) < 2050) or (int(val) > 0 and int(val) < 10):
                    found_entities_date.append(val)

    # For value recognition
    for token in doc:
        # Checke weather it is date or not
        if token.is_digit and str(token) not in found_entities_date:
            found_entities_vals.append(token)

    return [found_entities_elem, found_entities_date, found_entities_vals]

def predict(elem, period):

    current_year = 2024

    match elem:
        case "balance sheet":
            if int(period) > 2000:
                prediction = bilan.getPredictedBilan(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.getPredictedBilan(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."
            
        case "income statement":
            if int(period) > 2000:
                prediction = compte_resultat.getPredictedCompteResultat(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.getPredictedCompteResultat(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."
            
        case "cash flows":
            if int(period) > 2000:
                prediction = flux_tresorerie.getPredictedFluxTresorerie(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.getPredictedFluxTresorerie(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."
            
        case "income statement vertical analysis":
            if int(period) > 2000:
                prediction = compte_resultat.predictAnalyseVerticale(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictAnalyseVerticale(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."
            
        case "balance sheet vertical analysis":
            if int(period) > 2000:
                prediction = bilan.predictAnalyseVerticale(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictAnalyseVerticale(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."
            
        case "cash flows vertical analysis":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictAnalyseVerticale(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictAnalyseVerticale(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."
            
        case "fixed expenses":
            if int(period) > 2000:
                prediction = bilan.predictChargesImmobilisees(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictChargesImmobilisees(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "intangible fixed assets":
            if int(period) > 2000:
                prediction = bilan.predictImmobilisationCorporelle(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictImmobilisationCorporelle(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "- tangible fixed assets":
            if int(period) > 2000:
                prediction = bilan.predictImmobilisationIncorporelle(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictImmobilisationIncorporelle(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "financial fixed assets":
            if int(period) > 2000:
                prediction = bilan.predictImmobilisationFinanciere(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictImmobilisationFinanciere(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "amortisation provisions":
            if int(period) > 2000:
                prediction = bilan.predictAmortissementsProvisions(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictAmortissementsProvisions(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "total fixed assets":
            if int(period) > 2000:
                prediction = bilan.predictTotalActifImmobilises(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictTotalActifImmobilises(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "stock":
            if int(period) > 2000:
                prediction = bilan.predictStock(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictStock(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "suppliers, advances paid":
            if int(period) > 2000:
                prediction = bilan.predictFournisseursAvancesVersees(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictFournisseursAvancesVersees(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "receivables and equivalents":
            if int(period) > 2000:
                prediction = bilan.predictCreancesEmploisAssimiles(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictCreancesEmploisAssimiles(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "customers":
            if int(period) > 2000:
                prediction = bilan.predictclients(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictclients(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "other receivables":
            if int(period) > 2000:
                prediction = bilan.predictAutresCreances(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictAutresCreances(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "total current assets":
            if int(period) > 2000:
                prediction = bilan.predictTotalActifCirculant(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictTotalActifCirculant(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "total cash - assets":
            if int(period) > 2000:
                prediction = bilan.predictTotalTresorerieActif(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictTotalTresorerieActif(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "total assets":
            if int(period) > 2000:
                prediction = bilan.predictTotalActif(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictTotalActif(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "the capital":
            if int(period) > 2000:
                prediction = bilan.predictCapital(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictCapital(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "premiums and reserves":
            if int(period) > 2000:
                prediction = bilan.predictPrimesReserves(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictPrimesReserves(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "brought carried forward":
            if int(period) > 2000:
                prediction = bilan.predictReportANouveau(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictReportANouveau(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "conversion deviation":
            if int(period) > 2000:
                prediction = bilan.predictEcartDeConversion(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictEcartDeConversion(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "net result":
            if int(period) > 2000:
                prediction = bilan.predictAutresCapitauxPropres(int(period))
                return "The prediction of " + elem + " of the balance sheet in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictAutresCapitauxPropres(current_year+int(period))
                return "The prediction of " + elem + " of the balance sheet in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "other equity":
            if int(period) > 2000:
                prediction = bilan.predictResultatNet(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictResultatNet(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "company share":
            if int(period) > 2000:
                prediction = bilan.predictPartEntreprise(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictPartEntreprise(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "minority interest share":
            if int(period) > 2000:
                prediction = bilan.predictPartMinotaire(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictPartMinotaire(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "total shareholders' equity":
            if int(period) > 2000:
                prediction = bilan.predictTotalCapitauxPropres(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictTotalCapitauxPropres(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "deferred income taxes":
            if int(period) > 2000:
                prediction = bilan.predictInteretDiffere(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictInteretDiffere(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "loans and financial debts":
            if int(period) > 2000:
                prediction = bilan.predictEmpruntsDettesFinancieres(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictEmpruntsDettesFinancieres(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "financial provisions":
            if int(period) > 2000:
                prediction = bilan.predictProvisionFinanciere(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictProvisionFinanciere(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "total financial liabilities (ii)":
            if int(period) > 2000:
                prediction = bilan.predictTotalDettesFinancieres(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictTotalDettesFinancieres(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "current debts":
            if int(period) > 2000:
                prediction = bilan.predictDettesCirculant(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictDettesCirculant(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "customers advances received":
            if int(period) > 2000:
                prediction = bilan.predictFournisseursExploitation(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictFournisseursExploitation(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "operating suppliers":
            if int(period) > 2000:
                prediction = bilan.predictClientsAvancesRecues(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictClientsAvancesRecues(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "tax owed":
            if int(period) > 2000:
                prediction = bilan.predictDettesFiscales(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictDettesFiscales(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "social security liabilities":
            if int(period) > 2000:
                prediction = bilan.predictDettesSociales(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictDettesSociales(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "other payables":
            if int(period) > 2000:
                prediction = bilan.predictAutresDettes(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictAutresDettes(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "total current liabilities":
            if int(period) > 2000:
                prediction = bilan.predictTotalPassifCirculant(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictTotalPassifCirculant(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "total cash - liabilities":
            if int(period) > 2000:
                prediction = bilan.predictTotalTresoreriePassif(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictTotalTresoreriePassif(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "total liabilities":
            if int(period) > 2000:
                prediction = bilan.predictTotalPassif(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = bilan.predictTotalPassif(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."
                
        case "trading margin":
            if int(period) > 2000:
                prediction = compte_resultat.predictMargeCommericiale(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictMargeCommericiale(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "turnover":
            if int(period) > 2000:
                prediction = compte_resultat.predictChiffreDAffaires(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictChiffreDAffaires(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "inventoried products":
            if int(period) > 2000:
                prediction = compte_resultat.predictProductionStockee(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictProductionStockee(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "storage production":
            if int(period) > 2000:
                prediction = compte_resultat.predictProductionImmobilisee(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictProductionImmobilisee(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "other rots":
            if int(period) > 2000:
                prediction = compte_resultat.predictAutresProduits(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictAutresProduits(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "revenue for the year":
            if int(period) > 2000:
                prediction = compte_resultat.predictProductionExercice(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictProductionExercice(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "purchases consumed":
            if int(period) > 2000:
                prediction = compte_resultat.predictAchatsConsommes(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictAchatsConsommes(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "external services":
            if int(period) > 2000:
                prediction = compte_resultat.predictServicesExterieurs(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictServicesExterieurs(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "consumption for the year":
            if int(period) > 2000:
                prediction = compte_resultat.predictConsommationExercice(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictConsommationExercice(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "added value":
            if int(period) > 2000:
                prediction = compte_resultat.predictValeurAjoutee(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictValeurAjoutee(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "personnel costs":
            if int(period) > 2000:
                prediction = compte_resultat.predictChargesPersonnel(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictChargesPersonnel(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "gross operating surplus":
            if int(period) > 2000:
                prediction = compte_resultat.predictExcedentBruteDExploitation(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictExcedentBruteDExploitation(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "depreciation and amortization expenses":
            if int(period) > 2000:
                prediction = compte_resultat.predictDotationsAuxAmortissements(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictDotationsAuxAmortissements(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "reversals of provisions":
            if int(period) > 2000:
                prediction = compte_resultat.predictReprisesDeProvisions(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictReprisesDeProvisions(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "operating result":
            if int(period) > 2000:
                prediction = compte_resultat.predictResultatDExploitation(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictResultatDExploitation(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "financial income":
            if int(period) > 2000:
                prediction = compte_resultat.predictProduitsFinanciers(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictProduitsFinanciers(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "financial expenses":
            if int(period) > 2000:
                prediction = compte_resultat.predictChargesFinancieres(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictChargesFinancieres(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "financial results":
            if int(period) > 2000:
                prediction = compte_resultat.predictResultatFinanciers(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictResultatFinanciers(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "income from ordinary activity":
            if int(period) > 2000:
                prediction = compte_resultat.predictResultatDesActivitesOrdinaires(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictResultatDesActivitesOrdinaires(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "income excluding ordinary activities":
            if int(period) > 2000:
                prediction = compte_resultat.predictProduitsHOA(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictProduitsHOA(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "expenses excluding ordinary activities":
            if int(period) > 2000:
                prediction = compte_resultat.predictChargesHAO(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictChargesHAO(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "non-operating income":
            if int(period) > 2000:
                prediction = compte_resultat.predictResultatHOA(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictResultatHOA(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "result before taxes":
            if int(period) > 2000:
                prediction = compte_resultat.predictResultatAvantsImpots(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictResultatAvantsImpots(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "income taxes":
            if int(period) > 2000:
                prediction = compte_resultat.predictImpotsResultat(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictImpotsResultat(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "deferred income taxes":
            if int(period) > 2000:
                prediction = compte_resultat.predictImpotsDifferes(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictImpotsDifferes(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "net income of consolidated companies":
            if int(period) > 2000:
                prediction = compte_resultat.predictResultatNetDesEntreprisesIntegrees(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictResultatNetDesEntreprisesIntegrees(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "share put into equivalence":
            if int(period) > 2000:
                prediction = compte_resultat.predictPartMiseEnEquivalence(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictPartMiseEnEquivalence(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "consolidated net income":
            if int(period) > 2000:
                prediction = compte_resultat.predictResultatNetConsolide(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictResultatNetConsolide(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "minority interest share":
            if int(period) > 2000:
                prediction = compte_resultat.predictPartDesMinoritaires(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictPartDesMinoritaires(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "company share":
            if int(period) > 2000:
                prediction = compte_resultat.predictPartEntreprise(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = compte_resultat.predictPartEntreprise(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."
            
        case "initial cash flow":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictTresorerieInitiale(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictTresorerieInitiale(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "self-financing capacity":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictCapaciteautofinancement(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictCapaciteautofinancement(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "change in hao current assets":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictVariationactifCirculantHaO(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictVariationactifCirculantHaO(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "change in inventory":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictVariationStocks(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictVariationStocks(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "variation in receivables":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictVariationCreances(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictVariationCreances(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "variation in current liabilities":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictVariationPassifCirculant(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictVariationPassifCirculant(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "working capital requirement":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictVariationBFR(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictVariationBFR(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "cash flow from operating activities":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictFTactiviteOpretationnelles(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictFTactiviteOpretationnelles(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "disbursements related to acquisitions of intangible assets":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictDecaissementsLiesauxacquisitionsImmobilisationsIncorporelles(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictDecaissementsLiesauxacquisitionsImmobilisationsIncorporelles(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "disbursements related to acquisitions of property, plant and equipment":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictDecaissementsLiesauxacquisitionsImmobilisationsCorporelles(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictDecaissementsLiesauxacquisitionsImmobilisationsCorporelles(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "disbursements related to acquisitions of financial fixed assets":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictDecaissementsLiesauxacquisitionsImmobilisationsFinancieres(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictDecaissementsLiesauxacquisitionsImmobilisationsFinancieres(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "receipts related to acquisitions of intangible and tangible assets":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictEncaissementsLiesauxacquisitionsImmobilisationsIncorporellesetCorporelles(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictEncaissementsLiesauxacquisitionsImmobilisationsIncorporellesetCorporelles(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "cash receipts related to acquisitions of financial fixed assets":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictEncaissementsLiesauxacquisitionsImmobilisationsFinancieres(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictEncaissementsLiesauxacquisitionsImmobilisationsFinancieres(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "cash flow from investment activities":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictFTactiviteInvestissement(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictFTactiviteInvestissement(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "capital increase by new ratios":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictAugmentationduCapitalParapportsNouveaux(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictAugmentationduCapitalParapportsNouveaux(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "subsidies":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictSubventionexploitation(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictSubventionexploitation(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "deduction from capital":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictPrelevementSurLeCapital(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictPrelevementSurLeCapital(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "dividends paid":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictDividendesVerses(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictDividendesVerses(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "cash flow from equity":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictFluxdeTresorerieProvenantdesCapitauxPropres(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictFluxdeTresorerieProvenantdesCapitauxPropres(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "borrowings":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictEmprunts(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictEmprunts(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "other financial liabilities":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictAutresdettesFinancieres(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictAutresdettesFinancieres(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "repayment of loans and other financial debts":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictRemboursementempruntsetautresdettesFinanciers(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictRemboursementempruntsetautresdettesFinanciers(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "cash flow from foreign capital":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictFluxdeTresorerieProvenantdesCapitauxetrangers(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictFluxdeTresorerieProvenantdesCapitauxetrangers(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "cash flow from financing activities":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictFTactiviteFinancement(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictFTactiviteFinancement(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "variation of net cash":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictVariationdeTresorerieNette(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictVariationdeTresorerieNette(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

        case "final cash flow":
            if int(period) > 2000:
                prediction = flux_tresorerie.predictTresorerieFinale(int(period))
                return "The prediction of " + elem + " in the year " + period + " is " + str(prediction) + "."
            elif int(period) < 10:
                prediction = flux_tresorerie.predictTresorerieFinale(current_year+int(period))
                return "The prediction of " + elem + " in the next " + period + " year is " + str(prediction) + "."
            else:
                return "If you wanna predict " + elem + ", redifine year the or periode."

def get(elem, year):

    val = -1

    match elem:
        case "balance sheet":
            val = bilan.getBilan(year)
        case "balance sheet vertical analysis":
            val = bilan.analyseVerticale(year)
        case "income statement":
            val = compte_resultat.getCompteResultat(year)
        case "income statement vertical analysis":
            val = compte_resultat.analyseVerticale(year)
        case "cash flows":
            val = flux_tresorerie.getFluxTresorerie(year)
        case "cash flows vertical analysis":
            val = flux_tresorerie.analyseVerticale(year)
        case "fixed expenses":
            val = bilan.getChargesImmobilisees(year)
        case "intangible fixed assets":
            val = bilan.getImmobilisationsIncorporelles(year)
        case "- tangible fixed assets":
            val = bilan.getImmobilisationsCorporelles(year)
        case "financial fixed assets":
            val = bilan.getImmobilisationsFinancieres(year)
        case "amortisation provisions":
            val = bilan.getAmortissementsProvisions(year)
        case "total fixed assets":
            val = bilan.getTotalActifImmobilises(year)
        case "stock":
            val = bilan.getStock(year)
        case "suppliers, advances paid":
            val = bilan.getFournisseursAvancesVersees(year)
        case "receivables and equivalents":
            val = bilan.getCreancesEmploisAssimiles(year)
        case "customers":
            val = bilan.getClients(year)
        case "other receivables":
            val = bilan.getAutresCreances(year)
        case "total current assets":
            val = bilan.getTotalActifCirculant(year)
        case "total cash - assets":
            val = bilan.getTotalTresorerieActif(year)
        case "total assets":
            val = bilan.getTotalActif(year)
        case "the capital":
            val = bilan.getCapital(year)
        case "premiums and reserves":
            val = bilan.getPrimesReserves(year)
        case "brought carried forward":
            val = bilan.getReportANouveau(year)
        case "conversion deviation":
            val = bilan.getEcartDeConversion(year)
        case "net result":
            val = bilan.getResultatNet(year)
        case "other equity":
            val = bilan.getAutresCapitauxPropres(year)
        case "company share":
            val = bilan.getPartEentreprise(year)
        case "minority interest share":
            val = bilan.getPartDesMinoritaires(year)
        case "total shareholders' equity":
            val = bilan.getTotalCapitauxPropres(year)
        case "deferred income taxes":
            val = bilan.getImpotsDifferes(year)
        case "loans and financial debts":
            val = bilan.getEmpruntsDettesFinancieres(year)
        case "financial provisions":
            val = bilan.getProvisionsFinancieres(year)
        case "total financial liabilities (ii)":
            val = bilan.getTotalDettesFinancieres(year)
        case "current debts":
            val = bilan.getDettesCirculants(year)
        case "customers advances received":
            val = bilan.getClientsAvancesRecues(year)
        case "operating suppliers":
            val = bilan.getFournisseursExploitation(year)
        case "tax owed":
            val = bilan.getDettesFiscales(year)
        case "social security liabilities":
            val = bilan.getDettesSociales(year)
        case "other payables":
            val = bilan.getAutresDettes(year)
        case "total current liabilities":
            val = bilan.getTotalPassifCirculant(year)
        case "total cash - liabilities":
            val = bilan.getTotalTresoreriePassif(year)
        case "total liabilities":
            val = bilan.getTotalPassif(year)
        case "trading margin":
            val = compte_resultat.getMargeCommericiale(year)    
        case "turnover":
            val = compte_resultat.getChiffreDAffaires(year)    
        case "inventoried products":
            val = compte_resultat.getProductionStockee(year)    
        case "storage production":
            val = compte_resultat.getProductionImmobilisee(year)    
        case "other rots":
            val = compte_resultat.getAutresProduits(year)    
        case "revenue for the year":
            val = compte_resultat.getProductionExercice(year)    
        case "purchases consumed":
            val = compte_resultat.getAchatsConsommes(year)    
        case "external services":
            val = compte_resultat.getServicesExterieurs(year)    
        case "consumption for the year":
            val = compte_resultat.getConsommationExercice(year)    
        case "added value":
            val = compte_resultat.getValeurAjoutee(year)    
        case "personnel costs":
            val = compte_resultat.getChargesPersonnel(year)    
        case "gross operating surplus":
            val = compte_resultat.getExcedentBruteDExploitation(year)    
        case "depreciation and amortization expenses":
            val = compte_resultat.getDotationsAuxAmortissements(year)    
        case "reversals of provisions":
            val = compte_resultat.getReprisesDeProvisions(year)    
        case "operating result":
            val = compte_resultat.getResultatDExploitation(year)    
        case "financial income":
            val = compte_resultat.getProduitsFinanciers(year)    
        case "financial expenses":
            val = compte_resultat.getChargesFinancieres(year)    
        case "financial results":
            val = compte_resultat.getResultatFinanciers(year)    
        case "income from ordinary activity":
            val = compte_resultat.getResultatDesActivitesOrdinaires(year)    
        case "income excluding ordinary activities":
            val = compte_resultat.getProduitsHOA(year)    
        case "expenses excluding ordinary activities":
            val = compte_resultat.getChargesHAO(year)    
        case "non-operating income":
            val = compte_resultat.getResultatHOA(year)    
        case "result before taxes":
            val = compte_resultat.getResultatAvantsImpots(year)    
        case "income taxes":
            val = compte_resultat.getImpotsResultat(year)    
        case "deferred income taxes":
            val = compte_resultat.getImpotsDifferes(year)    
        case "net income of consolidated companies":
            val = compte_resultat.getResultatNetDesEntreprisesdefegrees(year)    
        case "share put into equivalence":
            val = compte_resultat.getPartMiseEnEquivalence(year)    
        case "consolidated net income":
            val = compte_resultat.getResultatNetConsolide(year)    
        case "minority interest share":
            val = compte_resultat.getPartDesMinoritaires(year)    
        case "company share":
            val = compte_resultat.getPartEntreprise(year)
        case "initial cash flow":
            val = flux_tresorerie.getTresorerieInitiale(year)
        case "self-financing capacity":
            val = flux_tresorerie.getCapaciteautofinancement(year)
        case "change in hao current assets":
            val = flux_tresorerie.getVariationactifCirculantHaO(year)
        case "change in inventory":
            val = flux_tresorerie.getVariationStocks(year)
        case "variation in receivables":
            val = flux_tresorerie.getVariationCreances(year)
        case "variation in current liabilities":
            val = flux_tresorerie.getVariationPassifCirculant(year)
        case "working capital requirement":
            val = flux_tresorerie.getVariationBFR(year)
        case "cash flow from operating activities":
            val = flux_tresorerie.getFTactiviteOpretationnelles(year)
        case "disbursements related to acquisitions of intangible assets":
            val = flux_tresorerie.getDecaissementsLiesauxacquisitionsImmobilisationsIncorporelles(year)
        case "disbursements related to acquisitions of property, plant and equipment":
            val = flux_tresorerie.getDecaissementsLiesauxacquisitionsImmobilisationsCorporelles(year)
        case "disbursements related to acquisitions of financial fixed assets":
            val = flux_tresorerie.getDecaissementsLiesauxacquisitionsImmobilisationsFinancieres(year)
        case "receipts related to acquisitions of intangible and tangible assets":
            val = flux_tresorerie.getEncaissementsLiesauxacquisitionsImmobilisationsIncorporellesetCorporelles(year)
        case "cash receipts related to acquisitions of financial fixed assets":
            val = flux_tresorerie.getEncaissementsLiesauxacquisitionsImmobilisationsFinancieres(year)
        case "cash flow from investment activities":
            val = flux_tresorerie.getFTactiviteInvestissement(year)
        case "capital increase by new ratios":
            val = flux_tresorerie.getAugmentationduCapitalParapportsNouveaux(year)
        case "subsidies":
            val = flux_tresorerie.getSubventionexploitation(year)
        case "deduction from capital":
            val = flux_tresorerie.getPrelevementSurLeCapital(year)
        case "dividends paid":
            val = flux_tresorerie.getDividendesVerses(year)
        case "cash flow from equity":
            val = flux_tresorerie.getFluxdeTresorerieProvenantdesCapitauxPropres(year)
        case "borrowings":
            val = flux_tresorerie.getEmprunts(year)
        case "other financial liabilities":
            val = flux_tresorerie.getAutresdettesFinancieres(year)
        case "repayment of loans and other financial debts":
            val = flux_tresorerie.getRemboursementempruntsetautresdettesFinanciers(year)
        case "cash flow from foreign capital":
            val = flux_tresorerie.getFluxdeTresorerieProvenantdesCapitauxetrangers(year)
        case "cash flow from financing activities":
            val = flux_tresorerie.getFTactiviteFinancement(year)
        case "variation of net cash":
            val = flux_tresorerie.getVariationdeTresorerieNette(year)
        case "final cash flow":
            val = flux_tresorerie.getTresorerieFinale(year)

    if year == 2019:
        return "The current value of " + elem + " is " + str(val)  + "."

    return "The value of " + elem + " by the year " + str(year) + " is " + str(val) + "."
        
def set(elem, val1, val2, year):

    match elem:
        case "fixed expenses":
            if bilan.setChargesImmobilisees(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "intangible fixed assets":
            if bilan.setImmobilisationsIncorporelles(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "- tangible fixed assets":
            if bilan.setImmobilisationsCorporelles(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "financial fixed assets":
            if bilan.setImmobilisationsFinancieres(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "amortisation provisions":
            if bilan.setAmortissementsProvisions(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "total fixed assets":
            if bilan.setTotalActifImmobilises(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "stock":
            if bilan.setStock(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "suppliers, advances paid":
            if bilan.setFournisseursAvancesVersees(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "receivables and equivalents":
            if bilan.setCreancesEmploisAssimiles(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "customers":
            if bilan.setClients(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "other receivables":
            if bilan.setAutresCreances(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "total current assets":
            if bilan.setTotalActifCirculant(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "total cash - assets":
            if bilan.setTotalTresorerieActif(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "total assets":
            if bilan.setTotalActif(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "the capital":
            if bilan.setCapital(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "premiums and reserves":
            if bilan.setPrimesReserves(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "brought carried forward":
            if bilan.setReportANouveau(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "conversion deviation":
            if bilan.setEcartDeConversion(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "net result":
            if bilan.setResultatNet(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "other equity":
            if bilan.setAutresCapitauxPropres(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "company share":
            if bilan.setPartEentreprise(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "minority interest share":
            if bilan.setPartDesMinoritaires(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "total shareholders' equity":
            if bilan.setTotalCapitauxPropres(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "deferred income taxes":
            if bilan.setImpotsDifferes(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "loans and financial debts":
            if bilan.setEmpruntsDettesFinancieres(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "financial provisions":
            if bilan.setProvisionsFinancieres(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "total financial liabilities (ii)":
            if bilan.setTotalDettesFinancieres(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "current debts":
            if bilan.setDettesCirculants(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "customers advances received":
            if bilan.setClientsAvancesRecues(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "operating suppliers":
            if bilan.setFournisseursExploitation(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "tax owed":
            if bilan.setDettesFiscales(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "social security liabilities":
            if bilan.setDettesSociales(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "other payables":
            if bilan.setAutresDettes(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "total current liabilities":
            if bilan.setTotalPassifCirculant(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "total cash - liabilities":
            if bilan.setTotalTresoreriePassif(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "total liabilities":
            if bilan.setTotalPassif(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "trading margin":
            if compte_resultat.setMargeCommericiale(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "turnover":
            if compte_resultat.setChiffreDAffaires(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "inventoried products":
            if compte_resultat.setProductionStockee(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "storage production":
            if compte_resultat.setProductionImmobilisee(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "other rots":
            if compte_resultat.setAutresProduits(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "revenue for the year":
            if compte_resultat.setProductionExercice(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "purchases consumed":
            if compte_resultat.setAchatsConsommes(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "external services":
            if compte_resultat.setServicesExterieurs(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "consumption for the year":
            if compte_resultat.setConsommationExercice(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "added value":
            if compte_resultat.setValeurAjoutee(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "personnel costs":
            if compte_resultat.setChargesPersonnel(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "gross operating surplus":
            if compte_resultat.setExcedentBruteDExploitation(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "depreciation and amortization expenses":
            if compte_resultat.setDotationsAuxAmortissements(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "reversals of provisions":
            if compte_resultat.setReprisesDeProvisions(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "operating result":
            if compte_resultat.setResultatDExploitation(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "financial income":
            if compte_resultat.setProduitsFinanciers(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "financial expenses":
            if compte_resultat.setChargesFinancieres(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "financial results":
            if compte_resultat.setResultatFinanciers(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "income from ordinary activity":
            if compte_resultat.setResultatDesActivitesOrdinaires(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "income excluding ordinary activities":
            if compte_resultat.setProduitsHOA(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "expenses excluding ordinary activities":
            if compte_resultat.setChargesHAO(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "non-operating income":
            if compte_resultat.setResultatHOA(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "result before taxes":
            if compte_resultat.setResultatAvantsImpots(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "income taxes":
            if compte_resultat.setImpotsResultat(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "deferred income taxes":
            if compte_resultat.setImpotsDifferes(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "net income of consolidated companies":
            if compte_resultat.setResultatNetDesEntreprisesdefegrees(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "share put into equivalence":
            if compte_resultat.setPartMiseEnEquivalence(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "consolidated net income":
            if compte_resultat.setResultatNetConsolide(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "minority interest share":
            if compte_resultat.setPartDesMinoritaires(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
                
        case "company share":
            if compte_resultat.setPartEntreprise(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
            
        case "initial cash flow":
            if flux_tresorerie.setTresorerieInitiale(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"

        case "self-financing capacity":
            if flux_tresorerie.setCapaciteautofinancement(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "change in hao current assets":
            if flux_tresorerie.setVariationactifCirculantHaO(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "change in inventory":
            if flux_tresorerie.setVariationStocks(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "variation in receivables":
            if flux_tresorerie.setVariationCreances(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "variation in current liabilities":
            if flux_tresorerie.setVariationPassifCirculant(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "working capital requirement":
            if flux_tresorerie.setVariationBFR(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "cash flow from operating activities":
            if flux_tresorerie.setFTactiviteOpretationnelles(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "disbursements related to acquisitions of intangible assets":
            if flux_tresorerie.setDecaissementsLiesauxacquisitionsImmobilisationsIncorporelles(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "disbursements related to acquisitions of property, plant and equipment":
            if flux_tresorerie.setDecaissementsLiesauxacquisitionsImmobilisationsCorporelles(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "disbursements related to acquisitions of financial fixed assets":
            if flux_tresorerie.setDecaissementsLiesauxacquisitionsImmobilisationsFinancieres(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "receipts related to acquisitions of intangible and tangible assets":
            if flux_tresorerie.setEncaissementsLiesauxacquisitionsImmobilisationsIncorporellesetCorporelles(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "cash receipts related to acquisitions of financial fixed assets":
            if flux_tresorerie.setEncaissementsLiesauxacquisitionsImmobilisationsFinancieres(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "cash flow from investment activities":
            if flux_tresorerie.setFTactiviteInvestissement(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "capital increase by new ratios":
            if flux_tresorerie.setAugmentationduCapitalParapportsNouveaux(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "subsidies":
            if flux_tresorerie.setSubventionexploitation(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "deduction from capital":
            if flux_tresorerie.setPrelèvementSurLeCapital(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "dividends paid":
            if flux_tresorerie.setDividendesVerses(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "cash flow from equity":
            if flux_tresorerie.setFluxdeTresorerieProvenantdesCapitauxPropres(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "borrowings":
            if flux_tresorerie.setEmprunts(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "other financial liabilities":
            if flux_tresorerie.setAutresdettesFinancières(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "repayment of loans and other financial debts":
            if flux_tresorerie.setRemboursementempruntsetautresdettesFinanciers(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "cash flow from foreign capital":
            if flux_tresorerie.setFluxdeTresorerieProvenantdesCapitauxetrangers(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "cash flow from financing activities":
            if flux_tresorerie.setFTactiviteFinancement(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "variation of net cash":
            if flux_tresorerie.setVariationdeTresorerieNette(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
        case "final cash flow":
            if flux_tresorerie.setTresorerieFinale(val2, year):
                return "The " + elem + " has been updated from " + str(val1) + " to " + str(val2) + " successfully !!! You can verify in the database." 
            else:
                return "Sorry! There could be an error while updating the value, try later !!!"
            
def definition(elem):

    for defs in definitions.keys():
        if elem == defs:
            random_index = math.floor(random.random() * len(definitions[defs]))
            return definitions[defs][random_index]
        
    return "You may wanna ask internet for this defintion !"

def calculate(val1, val2, op):

    match op:
        case "+":
            return "The resulat of " + str(val1) + " + " + str(val2) + " = " + str((val1 + val2))
        case "-":
            return "The resulat of " + str(val1) + " - " + str(val2) + " = " + str((val1 - val2))
        case "*":
            return "The resulat of " + str(val1) + " * " + str(val2) + " = " + str((val1 * val2))
        case "/":
            return "The resulat of " + str(val1) + " / " + str(val2) + " = " + str((val1 / val2))


def predict_response(question):

    found_entities_elem = entities_recognition(question)[0]
    found_entities_date = entities_recognition(question)[1]

    if not found_entities_elem:
        return "If you wanna make predict, then give a specific financial state"

    if not found_entities_date:
        return "If you wanna make predict, then give a specific date"

    texts = []
    for ent_elem in found_entities_elem:
        for ent_date in found_entities_date:
            texts.append(predict(ent_elem, ent_date))
            
    return "\n".join(texts)

def get_response(question):

    found_entities_elem = entities_recognition(question)[0]
    found_entities_date = entities_recognition(question)[1]

    if not found_entities_elem:
        return "If you wanna get a value, then give a specific financial statement element and a year !!!"

    texts = []
    for ent_elem in found_entities_elem:

        if not found_entities_date:
            year = 2019
            texts.append(get(ent_elem, year))
            continue

        for ent_date in found_entities_date: 
            texts.append(get(ent_elem, ent_date))
            
    return "\n".join(texts)

def set_response(question):

    found_entities_elem = entities_recognition(question)[0]
    found_entities_date = entities_recognition(question)[1]
    found_entities_vals = entities_recognition(question)[2]

    if not found_entities_elem:
        return "If you wanna set a value, then give a specific financial statement element !!!"
    
    if len(found_entities_elem) > 1:
        return "One element can be set at a times !!!"
    
    if len(found_entities_vals) < 2:
        return "Give every values we need for updating !!!"
    
    year = 2019
    for date in found_entities_date:
        if len(date) > 2:
            year = int(date)
            break

    texts = []
    for ent_elem in found_entities_elem:
        if not found_entities_date:
            texts.append(set(ent_elem, found_entities_vals[0], found_entities_vals[1], year))
            continue

        texts.append(set(ent_elem, found_entities_vals[0], found_entities_vals[1], year))
            
    return "\n".join(texts)
            
def definition_response(question):

    found_entities_elem = entities_recognition(question)[0]

    if not found_entities_elem:
        return "Give a specific financial statement element you want the definition !!!"

    texts = []
    for ent_elem in found_entities_elem:
        texts.append(definition(ent_elem))
            
    return "\n".join(texts)

def calculate_response(question):

    found_entities_vals = entities_recognition(question)[2]

    if len(found_entities_vals) != 2:
        return "For time being, I can make calculation only with two whole number !!!"

    if "+" in question or "add" in question:
        return calculate(float(str(found_entities_vals[0])), float(str(found_entities_vals[1])), "+")
    elif "-" in question or "substract" in question:
        return calculate(float(str(found_entities_vals[0])), float(str(found_entities_vals[1])), "-")
    elif "*" in question or "multiply" in question or "times" in question:
        return calculate(float(str(found_entities_vals[0])), float(str(found_entities_vals[1])), "*")
    elif "/" in question or "divide" in question or "over" in question:
        return calculate(float(str(found_entities_vals[0])), float(str(found_entities_vals[1])), "/")
    
def small_talk_response(question):

    responses = []
    if question in ["hello", "hi", "hey", "yo", "heya", "hey there", "morning", "howdy", "good morning", "good afternoon", "good evening"]:
        responses = [question+"! How can I help you today?", question+"! Tell me what can do for you.", question+"! What do you need today?"]
    else:
        responses = ["I am great. How can I help you today?", "Today is good. Tell me what can do for you.", "So far, so good, What do you need today?", "Good thank's you for asking, how can be useful for you today"]
    
    random_index = math.floor(random.random() * len(responses))

    return responses[random_index]

def thanks_response():
    responses =["You are welcome, If there anything else, let me know.", "I appriciate, tell me if there is anything else than I can do.", "No problem, it's my job, let me know whenever you need somethings."]
    random_index = math.floor(random.random() * len(responses))

    return responses[random_index]

def help_response():
    responses =["Tell me ! I am here to help you with financial statement.", "I will be happy to help with financial statement so tell me.", "Your problem, my probleme. Tell me and I will figure out how can I help you with financial statement."]
    random_index = math.floor(random.random() * len(responses))

    return responses[random_index]

def quit_response():
    responses =["Ok see you next.", "Good bye.", "I was a pleasure."]
    random_index = math.floor(random.random() * len(responses))

    return responses[random_index]

def confuse_response():

    message = "<br> Here are some areas that I can help you with.<br> - Predict values in your financial statements<br> - Get values from your financial statements<br> - Update values from your financial statements<br> - Define financial statement elements<br> - Make calcuations with only two whole numbre."

    responses =["I dont get that, please rephase it if possible !"+message, "I don't understand ! I can only help you with financial statement !"+message, "Can you please tell that in way that I could understant !"+message]
    random_index = math.floor(random.random() * len(responses))

    return responses[random_index]

def response(question, intent):

    match intent:

        case "small_talk":
            return small_talk_response(question)

        case "thanks": 
            return thanks_response()

        case "help":
            return help_response()

        case "predict":
            return predict_response(question)

        case "get":
            return get_response(question)

        case "set": 
            return set_response(question)

        case "calculate":
            return calculate_response(question)

        case "definition":
            return definition_response(question)

        case "quit":
            return quit_response()
        
        case "confuse":
            return confuse_response()

# ----------------
# ----------------
# ----------------
            
# question = input("You: ")
# print(response(question.lower(), "get"))