import mysql.connector

my_db =  mysql.connector.connect(host="localhost", user="root", password="", database="etatfinancier")
my_cursor = my_db.cursor()

class FluxTresorerie:
    def __init__(self) -> None:
        pass

    def getFluxTresorerie(self, year):
        return [self.getTresorerieInitiale(year), self.getCapaciteautofinancement(year), self.getVariationactifCirculantHaO(year), self.getVariationStocks(year), self.getVariationCreances(year), self.getVariationPassifCirculant(year), self.getVariationBFR(year), self.getFTactiviteOpretationnelles(year), self.getDecaissementsLiesauxacquisitionsImmobilisationsIncorporelles(year), self.getDecaissementsLiesauxacquisitionsImmobilisationsCorporelles(year), self.getDecaissementsLiesauxacquisitionsImmobilisationsFinancieres(year), self.getEncaissementsLiesauxacquisitionsImmobilisationsIncorporellesetCorporelles(year), self.getEncaissementsLiesauxacquisitionsImmobilisationsFinancieres(year), self.getFTactiviteInvestissement(year), self.getAugmentationduCapitalParapportsNouveaux(year), self.getSubventionexploitation(year), self.getPrelevementSurLeCapital(year), self.getDividendesVerses(year), self.getFluxdeTresorerieProvenantdesCapitauxPropres(year), self.getEmprunts(year), self.getAutresdettesFinancieres(year), self.getRemboursementempruntsetautresdettesFinanciers(year), self.getFluxdeTresorerieProvenantdesCapitauxetrangers(year), self.getFTactiviteFinancement(year), self.getVariationdeTresorerieNette(year), self.getTresorerieFinale(year)]
    
    def getPredictedFluxTresorerie(self, y):
        return [self.predictTresorerieInitiale(y), self.predictCapaciteautofinancement(y), self.predictVariationactifCirculantHaO(y), self.predictVariationStocks(y), self.predictVariationCreances(y), self.predictVariationPassifCirculant(y), self.predictVariationBFR(y), self.predictFTactiviteOpretationnelles(y), self.predictDecaissementsLiesauxacquisitionsImmobilisationsIncorporelles(y), self.predictDecaissementsLiesauxacquisitionsImmobilisationsCorporelles(y), self.predictDecaissementsLiesauxacquisitionsImmobilisationsFinancieres(y), self.predictEncaissementsLiesauxacquisitionsImmobilisationsIncorporellesetCorporelles(y), self.predictEncaissementsLiesauxacquisitionsImmobilisationsFinancieres(y), self.predictFTactiviteInvestissement(y), self.predictAugmentationduCapitalParapportsNouveaux(y), self.predictSubventionexploitation(y), self.predictPrelevementSurLeCapital(y), self.predictDividendesVerses(y), self.predictFluxdeTresorerieProvenantdesCapitauxPropres(y), self.predictEmprunts(y), self.predictAutresdettesFinancieres(y), self.predictRemboursementempruntsetautresdettesFinanciers(y), self.predictFluxdeTresorerieProvenantdesCapitauxetrangers(y), self.predictFTactiviteFinancement(y), self.predictVariationdeTresorerieNette(y), self.predictTresorerieFinale(y)]

    def analyseVerticale(self, year):
        av = []
        ft = self.getFluxTresorerie(year)

        for i in range(len(ft)):
            av.append(ft[i] / ft[len(ft)-1])

        return av
    
    def analyseHorizontale(self, year):
        ah = []
        ftc = self.getFluxTresorerie(year)
        ftp = self.getFluxTresorerie(year-1)

        for i in range(ftc):
            ah.append(ftc[i] / ftp[i] - 1.0)

        return ah
    
    def predictAnalyseVerticale(self, y):
        av = []
        ft = self.getPredictedFluxTresorerie(y)

        for i in range(ft):
            av.append(ft[i] / ft[len(ft)-1])

        return av
    
    def predictAnalyseHorizontale(self, y):
        ah = []
        ftc = self.getPredictedFluxTresorerie(y)
        ftp = self.getPredictedFluxTresorerie(y-1)

        for i in range(ftc):
            ah.append(ftc[i] / ftp[i] - 1.0)

        return ah

    # -----------GETTER-----------------
    def getTresorerieInitiale(self, year):
        QUERY = "SELECT tresorerieInitiale FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getCapaciteautofinancement(self, year):
        QUERY = "SELECT capaciteautofinancement FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getVariationactifCirculantHaO(self, year):
        QUERY = "SELECT variationactifCirculantHaO FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getVariationStocks(self, year):
        QUERY = "SELECT variationStocks FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getVariationCreances(self, year):
        QUERY = "SELECT variationCreances FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getVariationPassifCirculant(self, year):
        QUERY = "SELECT variationPassifCirculant FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getVariationBFR(self, year):
        QUERY = "SELECT variationBFR FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getFTactiviteOpretationnelles(self, year):
        QUERY = "SELECT FTactiviteOpretationnelles FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getDecaissementsLiesauxacquisitionsImmobilisationsIncorporelles(self, year):
        QUERY = "SELECT decaissementsLiesauxacquisitionsImmobilisationsIncorporelles FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getDecaissementsLiesauxacquisitionsImmobilisationsCorporelles(self, year):
        QUERY = "SELECT decaissementsLiesauxacquisitionsImmobilisationsCorporelles FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getDecaissementsLiesauxacquisitionsImmobilisationsFinancieres(self, year):
        QUERY = "SELECT decaissementsLiesauxacquisitionsImmobilisationsFinancieres FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getEncaissementsLiesauxacquisitionsImmobilisationsIncorporellesetCorporelles(self, year):
        QUERY = "SELECT encaissementsLiesauxacquisitionsImmobilisationsIncorpEtCorp FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getEncaissementsLiesauxacquisitionsImmobilisationsFinancieres(self, year):
        QUERY = "SELECT encaissementsLiesauxacquisitionsImmobilisationsFinancieres FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getFTactiviteInvestissement(self, year):
        QUERY = "SELECT FTactiviteInvestissement FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getAugmentationduCapitalParapportsNouveaux(self, year):
        QUERY = "SELECT augmentationduCapitalParapportsNouveaux FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getSubventionexploitation(self, year):
        QUERY = "SELECT subventionexploitation FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getPrelevementSurLeCapital(self, year):
        QUERY = "SELECT prelèvementSurLeCapital FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getDividendesVerses(self, year):
        QUERY = "SELECT dividendesVerses FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getFluxdeTresorerieProvenantdesCapitauxPropres(self, year):
        QUERY = "SELECT FluxdeTresorerieProvenantdesCapitauxPropres FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getEmprunts(self, year):
        QUERY = "SELECT emprunts FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getAutresdettesFinancieres(self, year):
        QUERY = "SELECT autresdettesFinancières FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getRemboursementempruntsetautresdettesFinanciers(self, year):
        QUERY = "SELECT remboursementempruntsetautresdettesFinanciers FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getFluxdeTresorerieProvenantdesCapitauxetrangers(self, year):
        QUERY = "SELECT FluxdeTresorerieProvenantdesCapitauxetrangers FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getFTactiviteFinancement(self, year):
        QUERY = "SELECT FTactiviteFinancement FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getVariationdeTresorerieNette(self, year):
        QUERY = "SELECT variationdeTresorerieNette FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getTresorerieFinale(self, year):
        QUERY = "SELECT tresorerieFinale FROM fluxTresorerie WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0] 
    
    # -----------SETTER-----------------
    def setTresorerieInitiale(self, val, year):
        self.tresorerieInitiale = val
        if self.tresorerieInitiale == val:
            
            UPDATE = "UPDATE fluxTresorerie SET tresorerieInitiale = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setCapaciteautofinancement(self, val, year):
        self.capaciteautofinancement = val
        if self.capaciteautofinancement == val:
            
            UPDATE = "UPDATE fluxTresorerie SET capaciteautofinancement = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setVariationactifCirculantHaO(self, val, year):
        self.variationactifCirculantHaO = val
        if self.variationactifCirculantHaO == val:
            
            UPDATE = "UPDATE fluxTresorerie SET variationactifCirculantHaO = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setVariationStocks(self, val, year):
        self.variationStocks = val
        if self.variationStocks == val:
            
            UPDATE = "UPDATE fluxTresorerie SET variationStocks = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setVariationCreances(self, val, year):
        self.variationCreances = val
        if self.variationCreances == val:
            
            UPDATE = "UPDATE fluxTresorerie SET variationCreances = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setVariationPassifCirculant(self, val, year):
        self.variationPassifCirculant = val
        if self.variationPassifCirculant == val:
            
            UPDATE = "UPDATE fluxTresorerie SET variationPassifCirculant = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setVariationBFR(self, val, year):
        self.variationBFR = val
        if self.variationBFR == val:
            
            UPDATE = "UPDATE fluxTresorerie SET variationBFR = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setFTactiviteOpretationnelles(self, val, year):
        self.FTactiviteOpretationnelles = val
        if self.FTactiviteOpretationnelles == val:
            
            UPDATE = "UPDATE fluxTresorerie SET FTactiviteOpretationnelles = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setDecaissementsLiesauxacquisitionsImmobilisationsIncorporelles(self, val, year):
        self.decaissementsLiesauxacquisitionsImmobilisationsIncorporelles = val
        if self.decaissementsLiesauxacquisitionsImmobilisationsIncorporelles == val:
            
            UPDATE = "UPDATE fluxTresorerie SET decaissementsLiesauxacquisitionsImmobilisationsIncorporelles = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setDecaissementsLiesauxacquisitionsImmobilisationsCorporelles(self, val, year):
        self.decaissementsLiesauxacquisitionsImmobilisationsCorporelles = val
        if self.decaissementsLiesauxacquisitionsImmobilisationsCorporelles == val:
            
            UPDATE = "UPDATE fluxTresorerie SET decaissementsLiesauxacquisitionsImmobilisationsCorporelles = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setDecaissementsLiesauxacquisitionsImmobilisationsFinancieres(self, val, year):
        self.decaissementsLiesauxacquisitionsImmobilisationsFinancieres = val
        if self.decaissementsLiesauxacquisitionsImmobilisationsFinancieres == val:
            
            UPDATE = "UPDATE fluxTresorerie SET decaissementsLiesauxacquisitionsImmobilisationsFinancieres = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setEncaissementsLiesauxacquisitionsImmobilisationsIncorporellesetCorporelles(self, val, year):
        self.encaissementsLiesauxacquisitionsImmobilisationsIncorporellesetCorporelles = val
        if self.encaissementsLiesauxacquisitionsImmobilisationsIncorporellesetCorporelles == val:
            
            UPDATE = "UPDATE fluxTresorerie SET encaissementsLiesauxacquisitionsImmobilisationsIncorpEtCorp = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setEncaissementsLiesauxacquisitionsImmobilisationsFinancieres(self, val, year):
        self.encaissementsLiesauxacquisitionsImmobilisationsFinancieres = val
        if self.encaissementsLiesauxacquisitionsImmobilisationsFinancieres == val:
            
            UPDATE = "UPDATE fluxTresorerie SET encaissementsLiesauxacquisitionsImmobilisationsFinancieres = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setFTactiviteInvestissement(self, val, year):
        self.FTactiviteInvestissement = val
        if self.FTactiviteInvestissement == val:
            
            UPDATE = "UPDATE fluxTresorerie SET FTactiviteInvestissement = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setAugmentationduCapitalParapportsNouveaux(self, val, year):
        self.augmentationduCapitalParapportsNouveaux = val
        if self.augmentationduCapitalParapportsNouveaux == val:
            
            UPDATE = "UPDATE fluxTresorerie SET augmentationduCapitalParapportsNouveaux = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setSubventionexploitation(self, val, year):
        self.subventionexploitation = val
        if self.subventionexploitation == val:
            
            UPDATE = "UPDATE fluxTresorerie SET subventionexploitation = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setPrelèvementSurLeCapital(self, val, year):
        self.prelèvementSurLeCapital = val
        if self.prelèvementSurLeCapital == val:
            
            UPDATE = "UPDATE fluxTresorerie SET prelèvementSurLeCapital = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setDividendesVerses(self, val, year):
        self.dividendesVerses = val
        if self.dividendesVerses == val:
            
            UPDATE = "UPDATE fluxTresorerie SET dividendesVerses = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setFluxdeTresorerieProvenantdesCapitauxPropres(self, val, year):
        self.FluxdeTresorerieProvenantdesCapitauxPropres = val
        if self.FluxdeTresorerieProvenantdesCapitauxPropres == val:
            
            UPDATE = "UPDATE fluxTresorerie SET FluxdeTresorerieProvenantdesCapitauxPropres = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setEmprunts(self, val, year):
        self.emprunts = val
        if self.emprunts == val:
            
            UPDATE = "UPDATE fluxTresorerie SET emprunts = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setAutresdettesFinancières(self, val, year):
        self.autresdettesFinancières = val
        if self.autresdettesFinancières == val:
            
            UPDATE = "UPDATE fluxTresorerie SET autresdettesFinancières = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setRemboursementempruntsetautresdettesFinanciers(self, val, year):
        self.remboursementempruntsetautresdettesFinanciers = val
        if self.remboursementempruntsetautresdettesFinanciers == val:
            
            UPDATE = "UPDATE fluxTresorerie SET remboursementempruntsetautresdettesFinanciers = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setFluxdeTresorerieProvenantdesCapitauxetrangers(self, val, year):
        self.FluxdeTresorerieProvenantdesCapitauxetrangers = val
        if self.FluxdeTresorerieProvenantdesCapitauxetrangers == val:
            
            UPDATE = "UPDATE fluxTresorerie SET FluxdeTresorerieProvenantdesCapitauxetrangers = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setFTactiviteFinancement(self, val, year):
        self.FTactiviteFinancement = val
        if self.FTactiviteFinancement == val:
            
            UPDATE = "UPDATE fluxTresorerie SET FTactiviteFinancement = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setVariationdeTresorerieNette(self, val, year):
        self.variationdeTresorerieNette = val
        if self.variationdeTresorerieNette == val:
            
            UPDATE = "UPDATE fluxTresorerie SET variationdeTresorerieNette = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setTresorerieFinale(self, val, year):
        self.tresorerieFinale = val
        if self.tresorerieFinale == val:
            
            UPDATE = "UPDATE fluxTresorerie SET tresorerieFinale = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    # -----------PREDICT----------
    def predictTresorerieInitiale(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictCapaciteautofinancement(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictVariationactifCirculantHaO(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictVariationStocks(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictVariationCreances(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictVariationPassifCirculant(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictVariationBFR(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictFTactiviteOpretationnelles(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictDecaissementsLiesauxacquisitionsImmobilisationsIncorporelles(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictDecaissementsLiesauxacquisitionsImmobilisationsCorporelles(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictDecaissementsLiesauxacquisitionsImmobilisationsFinancieres(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictEncaissementsLiesauxacquisitionsImmobilisationsIncorporellesetCorporelles(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictEncaissementsLiesauxacquisitionsImmobilisationsFinancieres(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictFTactiviteInvestissement(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictAugmentationduCapitalParapportsNouveaux(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictSubventionexploitation(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictPrelevementSurLeCapital(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictDividendesVerses(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictFluxdeTresorerieProvenantdesCapitauxPropres(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictEmprunts(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictAutresdettesFinancieres(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictRemboursementempruntsetautresdettesFinanciers(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictFluxdeTresorerieProvenantdesCapitauxetrangers(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictFTactiviteFinancement(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictVariationdeTresorerieNette(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictTresorerieFinale(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT