import mysql.connector

my_db =  mysql.connector.connect(host="localhost", user="root", password="", database="etatfinancier")
my_cursor = my_db.cursor()

QUERY = "SELECT * FROM bilan"
my_cursor.execute(QUERY)
bilan = my_cursor.fetchall()

QUERY = "SELECT * FROM compteResultat"
my_cursor.execute(QUERY)
compte_resultat = my_cursor.fetchall()


QUERY = "SELECT * FROM fluxTresorerie"
my_cursor.execute(QUERY)
flux_tresorerie = my_cursor.fetchall()

bilan_list = []
for i in bilan:
    bilan_list.append(list(i))

compte_resultat_list = []
for i in compte_resultat:
    compte_resultat_list.append(list(i))

flux_tresorerie_list = []
for i in flux_tresorerie:
    flux_tresorerie_list.append(list(i))

my_db.close()