import mysql.connector

my_db =  mysql.connector.connect(host="localhost", user="root", password="", database="etatfinancier")
my_cursor = my_db.cursor()

class Bilan:
    def __init__(self) -> None:
        pass

    def getBilan(self, year):
        return [self.getChargesImmobilisees(year), self.getImmobilisationsIncorporelles(year), self.getImmobilisationsCorporelles(year), self.getImmobilisationsFinancieres(year), self.getAmortissementsProvisions(year), self.getTotalActifImmobilises(year), self.getStock(year), self.getFournisseursAvancesVersees(year), self.getCreancesEmploisAssimiles(year), self.getClients(year), self.getAutresCreances(year), self.getTotalActifCirculant(year), self.getTotalTresorerieActif(year), self.getTotalActif(year), self.getCapital(year), self.getPrimesReserves(year), self.getReportANouveau(year), self.getEcartDeConversion(year), self.getResultatNet(year), self.getAutresCapitauxPropres(year), self.getPartEentreprise(year), self.getPartDesMinoritaires(year), self.getTotalCapitauxPropres(year), self.getImpotsDifferes(year), self.getEmpruntsDettesFinancieres(year), self.getProvisionsFinancieres(year), self.getTotalDettesFinancieres(year), self.getDettesCirculants(year), self.getClientsAvancesRecues(year), self.getFournisseursExploitation(year), self.getDettesFiscales(year), self.getDettesSociales(year), self.getAutresDettes(year), self.getTotalPassifCirculant(year), self.getTotalTresoreriePassif(year)]

    def getPredictedBilan(self, y):
        return [self.predictChargesImmobilisees(y), self.predictImmobilisationCorporelle(y), self.predictImmobilisationIncorporelle(y), self.predictImmobilisationFinanciere(y), self.predictAmortissementsProvisions(y), self.predictTotalActifImmobilises(y), self.predictStock(y), self.predictFournisseursAvancesVersees(y), self.predictCreancesEmploisAssimiles(y), self.predictclients(y), self.predictAutresCreances(y), self.predictTotalActifCirculant(y), self.predictTotalTresorerieActif(y), self.predictTotalActif(y), self.predictCapital(y), self.predictPrimesReserves(y), self.predictReportANouveau(y), self.predictEcartDeConversion(y), self.predictAutresCapitauxPropres(y), self.predictResultatNet(y), self.predictPartEntreprise(y), self.predictPartMinotaire(y), self.predictTotalCapitauxPropres(y), self.predictInteretDiffere(y), self.predictEmpruntsDettesFinancieres(y), self.predictProvisionFinanciere(y), self.predictTotalDettesFinancieres(y), self.predictDettesCirculant(y), self.predictFournisseursExploitation(y), self.predictClientsAvancesRecues(y), self.predictDettesFiscales(y), self.predictDettesSociales(y), self.predictAutresDettes(y), self.predictTotalPassifCirculant(y), self.predictTotalTresoreriePassif(y), self.predictTotalPassif(y)]


    def analyseVerticale(self, year):
        av = []
        b = self.getBilan(year)

        for i in range(14):
            av.append(b[i] / b[13])

        for i in range(14, len(b)):
            av.append(b[i] / b[len(b)-1])

        return av

    def analyseHorizontale(self, year):
        av = []
        bc = self.getBilan(year)
        bp = self.getBilan(year-1)

        for i in range(len(bc)):
            av.append(bc[i] / bp[i] - 1.0)

        return av

    def predictAnalyseVerticale(self, y):
        av = []
        b = self.getPredictedBilan(y)

        for i in range(14):
            av.append(b[i] / b[13])

        for i in range(14, len(b)):
            av.append(b[i] / b[len(b)-1])

        return av

    def predictAnalyseHorizontale(self, y):
        av = []
        bc = self.getPredictedBilan(y)
        bp = self.getPredictedBilan(y-1)

        for i in range(len(bc)):
            av.append(bc[i] / bp[i] - 1.0)

        return av

    # -----------GETTER-------------
    def getChargesImmobilisees(self, year):

        QUERY = "SELECT chargesImmobilisees FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getImmobilisationsIncorporelles(self, year):
        QUERY = "SELECT immobilisationsIncorporelles FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getImmobilisationsCorporelles(self, year):
        QUERY = "SELECT immobilisationsCorporelles FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getImmobilisationsFinancieres(self, year):
        QUERY = "SELECT immobilisationsFinancieres FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getAmortissementsProvisions(self, year):
        QUERY = "SELECT amortissementsProvisions FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getTotalActifImmobilises(self, year):
        QUERY = "SELECT totalActifImmobilises FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getStock(self, year):
        QUERY = "SELECT stock FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getFournisseursAvancesVersees(self, year):
        QUERY = "SELECT fournisseursAvancesVersees FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getCreancesEmploisAssimiles(self, year):
        QUERY = "SELECT creancesEmploisAssimiles FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getClients(self, year):
        QUERY = "SELECT clients FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getAutresCreances(self, year):
        QUERY = "SELECT autresCreances FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getTotalActifCirculant(self, year):
        QUERY = "SELECT totalActifCirculant FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getTotalTresorerieActif(self, year):
        QUERY = "SELECT totalTresorerieActif FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getTotalActif(self, year):
        QUERY = "SELECT totalActif FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getCapital(self, year):
        QUERY = "SELECT capital FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getPrimesReserves(self, year):
        QUERY = "SELECT primesReserves FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getReportANouveau(self, year):
        QUERY = "SELECT reportANouveau FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getEcartDeConversion(self, year):
        QUERY = "SELECT ecartDeConversion FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getResultatNet(self, year):
        QUERY = "SELECT resultatNet FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getAutresCapitauxPropres(self, year):
        QUERY = "SELECT autresCapitauxPropres FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getPartEentreprise(self, year):
        QUERY = "SELECT partEentreprise FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getPartDesMinoritaires(self, year):
        QUERY = "SELECT partDesMinoritaires FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getTotalCapitauxPropres(self, year):
        QUERY = "SELECT totalCapitauxPropres FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getImpotsDifferes(self, year):
        QUERY = "SELECT impotsDifferes FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getEmpruntsDettesFinancieres(self, year):
        QUERY = "SELECT empruntsDettesFinancieres FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getProvisionsFinancieres(self, year):
        QUERY = "SELECT provisionsFinancieres FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getTotalDettesFinancieres(self, year):
        QUERY = "SELECT totalDettesFinancieres FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getDettesCirculants(self, year):
        QUERY = "SELECT dettesCirculants FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getClientsAvancesRecues(self, year):
        QUERY = "SELECT clientsAvancesRecues FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getFournisseursExploitation(self, year):
        QUERY = "SELECT fournisseursExploitation FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getDettesFiscales(self, year):
        QUERY = "SELECT dettesFiscales FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getDettesSociales(self, year):
        QUERY = "SELECT dettesSociales FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getAutresDettes(self, year):
        QUERY = "SELECT autresDettes FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getTotalPassifCirculant(self, year):
        QUERY = "SELECT totalPassifCirculant FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getTotalTresoreriePassif(self, year):
        QUERY = "SELECT totalTresoreriePassif FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    def getTotalPassif(self, year):
        QUERY = "SELECT totalPassif FROM bilan WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    # -----------SETTER----------
    def setChargesImmobilisees(self, val, year):
        self.chargesImmobilisees = val
        if self.chargesImmobilisees == val:

            UPDATE = "UPDATE bilan SET chargesImmobilisees = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setImmobilisationsIncorporelles(self, val, year):
        self.immobilisationsIncorporelles = val
        if self.immobilisationsIncorporelles == val:
            
            UPDATE = "UPDATE bilan SET immobilisationsIncorporelles = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setImmobilisationsCorporelles(self, val, year):
        self.immobilisationsCorporelles = val
        if self.immobilisationsCorporelles == val:
            
            UPDATE = "UPDATE bilan SET immobilisationsCorporelles = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setImmobilisationsFinancieres(self, val, year):
        self.immobilisationsFinancieres = val
        if self.immobilisationsFinancieres == val:
            
            UPDATE = "UPDATE bilan SET immobilisationsFinancieres = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setAmortissementsProvisions(self, val, year):
        self.amortissementsProvisions = val
        if self.amortissementsProvisions == val:
            
            UPDATE = "UPDATE bilan SET amortissementsProvisions = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setTotalActifImmobilises(self, val, year):
        self.totalActifImmobilises = val
        if self.totalActifImmobilises == val:
            
            UPDATE = "UPDATE bilan SET totalActifImmobilises = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setStock(self, val, year):
        self.stock = val
        if self.stock == val:
            
            UPDATE = "UPDATE bilan SET stock = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setFournisseursAvancesVersees(self, val, year):
        self.fournisseursAvancesVersees = val
        if self.fournisseursAvancesVersees == val:
            
            UPDATE = "UPDATE bilan SET fournisseursAvancesVersees = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setCreancesEmploisAssimiles(self, val, year):
        self.creancesEmploisAssimiles = val
        if self.creancesEmploisAssimiles == val:
            
            UPDATE = "UPDATE bilan SET creancesEmploisAssimiles = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setClients(self, val, year):
        self.clients = val
        if self.clients == val:
            
            UPDATE = "UPDATE bilan SET clients = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setAutresCreances(self, val, year):
        self.autresCreances = val
        if self.autresCreances == val:
            
            UPDATE = "UPDATE bilan SET autresCreances = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setTotalActifCirculant(self, val, year):
        self.totalActifCirculant = val
        if self.totalActifCirculant == val:
            
            UPDATE = "UPDATE bilan SET totalActifCirculant = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setTotalTresorerieActif(self, val, year):
        self.totalTresorerieActif = val
        if self.totalTresorerieActif == val:
            
            UPDATE = "UPDATE bilan SET totalTresorerieActif = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setTotalActif(self, val, year):
        self.totalActif = val
        if self.totalActif == val:
            
            UPDATE = "UPDATE bilan SET totalActif = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setCapital(self, val, year):
        self.capital = val
        if self.capital == val:
            
            UPDATE = "UPDATE bilan SET capital = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setPrimesReserves(self, val, year):
        self.primesReserves = val
        if self.primesReserves == val:
            
            UPDATE = "UPDATE bilan SET primesReserves = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setReportANouveau(self, val, year):
        self.reportANouveau = val
        if self.reportANouveau == val:
            
            UPDATE = "UPDATE bilan SET reportANouveau = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setEcartDeConversion(self, val, year):
        self.ecartDeConversion = val
        if self.ecartDeConversion == val:
            
            UPDATE = "UPDATE bilan SET ecartDeConversion = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setResultatNet(self, val, year):
        self.resultatNet = val
        if self.resultatNet == val:
            
            UPDATE = "UPDATE bilan SET resultatNet = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setAutresCapitauxPropres(self, val, year):
        self.autresCapitauxPropres = val
        if self.autresCapitauxPropres == val:
            
            UPDATE = "UPDATE bilan SET autresCapitauxPropres = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setPartEentreprise(self, val, year):
        self.partEentreprise = val
        if self.partEentreprise == val:
            
            UPDATE = "UPDATE bilan SET partEentreprise = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setPartDesMinoritaires(self, val, year):
        self.partDesMinoritaires = val
        if self.partDesMinoritaires == val:
            
            UPDATE = "UPDATE bilan SET partDesMinoritaires = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setTotalCapitauxPropres(self, val, year):
        self.totalCapitauxPropres = val
        if self.totalCapitauxPropres == val:
            
            UPDATE = "UPDATE bilan SET totalCapitauxPropres = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setImpotsDifferes(self, val, year):
        self.impotsDifferes = val
        if self.impotsDifferes == val:
            
            UPDATE = "UPDATE bilan SET impotsDifferes = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setEmpruntsDettesFinancieres(self, val, year):
        self.empruntsDettesFinancieres = val
        if self.empruntsDettesFinancieres == val:
            
            UPDATE = "UPDATE bilan SET empruntsDettesFinancieres = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setProvisionsFinancieres(self, val, year):
        self.provisionsFinancieres = val
        if self.provisionsFinancieres == val:
            
            UPDATE = "UPDATE bilan SET provisionsFinancieres = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setTotalDettesFinancieres(self, val, year):
        self.totalDettesFinancieres = val
        if self.totalDettesFinancieres == val:
            
            UPDATE = "UPDATE bilan SET totalDettesFinancieres = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setDettesCirculants(self, val, year):
        self.dettesCirculants = val
        if self.dettesCirculants == val:
            
            UPDATE = "UPDATE bilan SET dettesCirculants = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setClientsAvancesRecues(self, val, year):
        self.clientsAvancesRecues = val
        if self.clientsAvancesRecues == val:
            
            UPDATE = "UPDATE bilan SET clientsAvancesRecues = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setFournisseursExploitation(self, val, year):
        self.fournisseursExploitation = val
        if self.fournisseursExploitation == val:
            
            UPDATE = "UPDATE bilan SET fournisseursExploitation = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setDettesFiscales(self, val, year):
        self.dettesFiscales = val
        if self.dettesFiscales == val:
            
            UPDATE = "UPDATE bilan SET dettesFiscales = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setDettesSociales(self, val, year):
        self.dettesSociales = val
        if self.dettesSociales == val:
            
            UPDATE = "UPDATE bilan SET dettesSociales = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setAutresDettes(self, val, year):
        self.autresDettes = val
        if self.autresDettes == val:
            
            UPDATE = "UPDATE bilan SET autresDettes = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setTotalPassifCirculant(self, val, year):
        self.totalPassifCirculant = val
        if self.totalPassifCirculant == val:
            
            UPDATE = "UPDATE bilan SET totalPassifCirculant = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setTotalTresoreriePassif(self, val, year):
        self.totalTresoreriePassif = val
        if self.totalTresoreriePassif == val:
            
            UPDATE = "UPDATE bilan SET totalTresoreriePassif = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    def setTotalPassif(self, val, year):
        self.totalPassif = val
        if self.totalPassif == val:
            
            UPDATE = "UPDATE bilan SET totalPassif = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()

            return True
        else:
            return False

    # -----------PREDICT----------
    def predictChargesImmobilisees(self, y):
        COEFFICIENT = -91.15810277
        INTERCEPT = 183827.60079051

        return COEFFICIENT * y + INTERCEPT

    def predictImmobilisationCorporelle(self, y):
        COEFFICIENT0 = 0.00000000e+00
        COEFFICIENT1 = -4.17210459e+06
        COEFFICIENT2 = 1.04126033e+03
        INTERCEPT = 4.17918018e+09

        return COEFFICIENT0 + COEFFICIENT1 * y + COEFFICIENT2 * pow(y, 2) + INTERCEPT

    def predictImmobilisationIncorporelle(self, y):
        COEFFICIENT = 27954.21936759
        INTERCEPT = -55739313.40316205

        return COEFFICIENT * y + INTERCEPT

    def predictImmobilisationFinanciere(self, y):
        COEFFICIENT0 = 0.00000000e+00
        COEFFICIENT1 = -2.33299917e+06
        COEFFICIENT2 = 5.83074788e+02
        INTERCEPT = 2.33370722e+09

        return COEFFICIENT0 + (COEFFICIENT1 * y) + (COEFFICIENT2 * pow(y, 2)) + INTERCEPT

    def predictAmortissementsProvisions(self, y):
        COEFFICIENT = 0
        INTERCEPT = 0

        return COEFFICIENT * y + INTERCEPT

    def predictTotalActifImmobilises(self, y):
        COEFFICIENT0 = 0.00000000e+00
        COEFFICIENT1 = -7.51855857e+06
        COEFFICIENT2 = 1.88373735e+03
        INTERCEPT = 7.50236233e+09

        return COEFFICIENT0 + (COEFFICIENT1 * y) + (COEFFICIENT2 * pow(y, 2)) + INTERCEPT

    def predictStock(self, y):
        COEFFICIENT = 712.7826087
        INTERCEPT = -1421586.91304348

        return COEFFICIENT * y + INTERCEPT

    def predictFournisseursAvancesVersees(self, y):
        COEFFICIENT = 0
        INTERCEPT = 0

        return COEFFICIENT * y + INTERCEPT

    def predictCreancesEmploisAssimiles(self, y):
        COEFFICIENT = 0
        INTERCEPT = 0

        return COEFFICIENT * y + INTERCEPT

    def predictclients(self, y):
        COEFFICIENT = 5457.0958498
        INTERCEPT = -10873906.50988142

        return COEFFICIENT * y + INTERCEPT

    def predictAutresCreances(self, y):
        COEFFICIENT = 4845.13438735
        INTERCEPT = -9651379.84980237

        return COEFFICIENT * y + INTERCEPT

    def predictTotalActifCirculant(self, y):
        COEFFICIENT = 10955.4812253
        INTERCEPT = -21827712.99604743

        return COEFFICIENT * y + INTERCEPT

    def predictTotalTresorerieActif(self, y):
        COEFFICIENT = 14159.49604743
        INTERCEPT = -28288445.93280633

        return COEFFICIENT * y + INTERCEPT

    def predictTotalActif(self, y):
        COEFFICIENT0 = 0.00000000e+00
        COEFFICIENT1 = -8.48790609e+06
        COEFFICIENT2 = 2.13136925e+03
        INTERCEPT = 8.4506489e+09

        return COEFFICIENT0 + (COEFFICIENT1 * y) + (COEFFICIENT2 * pow(y, 2)) + INTERCEPT

    def predictCapital(self, y):
        return 50000

    def predictPrimesReserves(self, y):
        COEFFICIENT = 18334.50592885
        INTERCEPT = -36568454.55731225

        return COEFFICIENT * y + INTERCEPT

    def predictReportANouveau(self, y):
        COEFFICIENT = 0
        INTERCEPT = 0

        return COEFFICIENT * y + INTERCEPT

    def predictEcartDeConversion(self, y):
        COEFFICIENT = 0
        INTERCEPT = 0

        return COEFFICIENT * y + INTERCEPT

    def predictAutresCapitauxPropres(self, y):
        COEFFICIENT = 0
        INTERCEPT = 0

        return COEFFICIENT * y + INTERCEPT

    def predictResultatNet(self, y):
        COEFFICIENT = 8378.87648221
        INTERCEPT = -16703707.32411067

        return COEFFICIENT * y + INTERCEPT

    def predictPartEntreprise(self, y):
        COEFFICIENT = 25997.8201581
        INTERCEPT = -51785891.26877471

        return COEFFICIENT * y + INTERCEPT


    def predictPartMinotaire(self, y):
        COEFFICIENT = 4743.9486166
        INTERCEPT = -9484598.4743083

        return COEFFICIENT * y + INTERCEPT

    def predictTotalCapitauxPropres(self, y):
        COEFFICIENT = 30741.73913043
        INTERCEPT = -61270428.99999998

        return COEFFICIENT * y + INTERCEPT


    def predictInteretDiffere(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictEmpruntsDettesFinancieres(self, y):
        COEFFICIENT0 = 0.00000000e+00
        COEFFICIENT1 = -2.93859783e+06
        COEFFICIENT2 = 7.32715472e+02
        INTERCEPT = 2.94636848e+09

        return COEFFICIENT0 + (COEFFICIENT1 * y) + (COEFFICIENT2 * pow(y, 2)) + INTERCEPT

    def predictProvisionFinanciere(self, y):
        COEFFICIENT = 3101.97826087
        INTERCEPT = -6201771.47826087

        return COEFFICIENT * y + INTERCEPT

    def predictTotalDettesFinancieres(self, y):
        COEFFICIENT0 = 0.00000000e+00
        COEFFICIENT1 = -3.73259256e+06
        COEFFICIENT2 = 9.31203783e+02
        INTERCEPT = 3.74041078e+09

        return COEFFICIENT0 + (COEFFICIENT1 * y) + (COEFFICIENT2 * pow(y, 2)) + INTERCEPT

    def predictDettesCirculant(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictFournisseursExploitation(self, y):
        COEFFICIENT = 12764.19762846
        INTERCEPT = -25513393.05533596

        return COEFFICIENT * y + INTERCEPT

    def predictClientsAvancesRecues(self, y):
        COEFFICIENT = 0
        INTERCEPT = 0

        return COEFFICIENT * y + INTERCEPT

    def predictDettesFiscales(self, y):
        COEFFICIENT = 0
        INTERCEPT = 0

        return COEFFICIENT * y + INTERCEPT

    def predictDettesSociales(self, y):
        COEFFICIENT = 0
        INTERCEPT = 0

        return COEFFICIENT * y + INTERCEPT

    def predictAutresDettes(self, y):
        COEFFICIENT0 = 0.00000000e+00
        COEFFICIENT1 = -2.40376161e+06
        COEFFICIENT2 = 6.01928233e+02
        INTERCEPT = 2.39984768e+09

        return COEFFICIENT0 + (COEFFICIENT1 * y) + (COEFFICIENT2 * pow(y, 2)) + INTERCEPT

    def predictTotalPassifCirculant(self, y):
        COEFFICIENT0 = 0.00000000e+00
        COEFFICIENT1 = -4.00030285e+06
        COEFFICIENT2 = 1.00251237e+03
        INTERCEPT = 3.99062354e+09

        return COEFFICIENT0 + (COEFFICIENT1 * y) + (COEFFICIENT2 * pow(y, 2)) + INTERCEPT

    def predictTotalTresoreriePassif(self, y):
        COEFFICIENT0 = 0.00000000e+00
        COEFFICIENT1 = -2.9239783e+06
        COEFFICIENT2 = 7.3007908e+02
        INTERCEPT = 2.92764355e+09

        return COEFFICIENT0 + (COEFFICIENT1 * y) + (COEFFICIENT2 * pow(y, 2)) + INTERCEPT

    def predictTotalPassif(self, y):
        COEFFICIENT0 = 0.00000000e+00
        COEFFICIENT1 = -8.48790609e+06
        COEFFICIENT2 = 2.13136925e+03
        INTERCEPT = 8.4506489e+09

        return COEFFICIENT0 + (COEFFICIENT1 * y) + (COEFFICIENT2 * pow(y, 2)) + INTERCEPT
    
# my_db.close()