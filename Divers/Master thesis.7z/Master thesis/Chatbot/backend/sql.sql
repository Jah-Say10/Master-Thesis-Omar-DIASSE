CREATE DATABASE etatFinancier;

USE etatFinancier;

CREATE TABLE bilan
(
    id INT AUTO_INCREMENT PRIMARY KEY,
    year INT UNIQUE,
    chargesImmobilisees DECIMAL(9, 0) DEFAULT 0,
    immobilisationsIncorporelles DECIMAL(9, 0) DEFAULT 0,
    immobilisationsCorporelles DECIMAL(9, 0) DEFAULT 0,
    immobilisationsFinancieres DECIMAL(9, 0) DEFAULT 0,
    amortissementsProvisions DECIMAL(9, 0) DEFAULT 0,
    totalActifImmobilises DECIMAL(9, 0) DEFAULT 0,
    stock DECIMAL(9, 0) DEFAULT 0,
    fournisseursAvancesVersees DECIMAL(9, 0) DEFAULT 0,
    creancesEmploisAssimiles DECIMAL(9, 0) DEFAULT 0,
    clients DECIMAL(9, 0) DEFAULT 0,
    autresCreances DECIMAL(9, 0) DEFAULT 0,
    totalActifCirculant DECIMAL(9, 0) DEFAULT 0,
    totalTresorerieActif DECIMAL(9, 0) DEFAULT 0,
    totalActif DECIMAL(9, 0) DEFAULT 0,
    capital DECIMAL(9, 0) DEFAULT 0,
    primesReserves DECIMAL(9, 0) DEFAULT 0,
    reportANouveau DECIMAL(9, 0) DEFAULT 0,
    ecartDeConversion DECIMAL(9, 0) DEFAULT 0,
    resultatNet DECIMAL(9, 0) DEFAULT 0,
    autresCapitauxPropres DECIMAL(9, 0) DEFAULT 0,
    partEentreprise DECIMAL(9, 0) DEFAULT 0,
    partDesMinoritaires DECIMAL(9, 0) DEFAULT 0,
    totalCapitauxPropres DECIMAL(9, 0) DEFAULT 0,
    impotsDifferes DECIMAL(9, 0) DEFAULT 0,
    empruntsDettesFinancieres DECIMAL(9, 0) DEFAULT 0,
    provisionsFinancieres DECIMAL(9, 0) DEFAULT 0,
    totalDettesFinancieres DECIMAL(9, 0) DEFAULT 0,
    dettesCirculants DECIMAL(9, 0) DEFAULT 0,
    clientsAvancesRecues DECIMAL(9, 0) DEFAULT 0,
    fournisseursExploitation DECIMAL(9, 0) DEFAULT 0,
    dettesFiscales DECIMAL(9, 0) DEFAULT 0,
    dettesSociales DECIMAL(9, 0) DEFAULT 0,
    autresDettes DECIMAL(9, 0) DEFAULT 0,
    totalPassifCirculant DECIMAL(9, 0) DEFAULT 0,
    totalTresoreriePassif DECIMAL(9, 0) DEFAULT 0,
    totalPassif DECIMAL(9, 0) DEFAULT 0
);

CREATE TABLE compteResultat
(
    id INT AUTO_INCREMENT PRIMARY KEY,
    year INT UNIQUE,
    margeCommerciale DECIMAL(9, 0) DEFAULT 0,
    chiffreDAffaires DECIMAL(9, 0) DEFAULT 0,
    productionStockee DECIMAL(9, 0) DEFAULT 0,
    productionImmobilisee DECIMAL(9, 0) DEFAULT 0,
    autresProduits DECIMAL(9, 0) DEFAULT 0,
    productionExercice DECIMAL(9, 0) DEFAULT 0,
    achatsConsommes DECIMAL(9, 0) DEFAULT 0,
    servicesExterieurs DECIMAL(9, 0) DEFAULT 0,
    consommationExercice DECIMAL(9, 0) DEFAULT 0,
    valeurAjoutee DECIMAL(9, 0) DEFAULT 0,
    chargesPersonnel DECIMAL(9, 0) DEFAULT 0,
    excedentBruteDExploitation DECIMAL(9, 0) DEFAULT 0,
    dotationsAuxAmortissements DECIMAL(9, 0) DEFAULT 0,
    reprisesDeProvisions DECIMAL(9, 0) DEFAULT 0,
    resultatDExploitation DECIMAL(9, 0) DEFAULT 0,
    produitsFinanciers DECIMAL(9, 0) DEFAULT 0,
    chargesFinancieres DECIMAL(9, 0) DEFAULT 0,
    resultatFinanciers DECIMAL(9, 0) DEFAULT 0,
    resultatDesActivitesOrdinaires DECIMAL(9, 0) DEFAULT 0,
    produitsHOA DECIMAL(9, 0) DEFAULT 0,
    chargesHAO DECIMAL(9, 0) DEFAULT 0,
    resultatHOA DECIMAL(9, 0) DEFAULT 0,
    resultatAvantsImpots DECIMAL(9, 0) DEFAULT 0,
    impotsResultat DECIMAL(9, 0) DEFAULT 0,
    impotsDifferes DECIMAL(9, 0) DEFAULT 0,
    resultatNetDesEntreprisesIntegrees DECIMAL(9, 0) DEFAULT 0,
    partMiseEnEquivalence DECIMAL(9, 0) DEFAULT 0,
    resultatNetConsolide DECIMAL(9, 0) DEFAULT 0,
    partDesMinoritaires DECIMAL(9, 0) DEFAULT 0,
    partEntreprise DECIMAL(9, 0) DEFAULT 0
);

CREATE TABLE fluxTresorerie
(
    id INT AUTO_INCREMENT PRIMARY KEY,
    year INT UNIQUE,
    tresorerieInitiale DECIMAL(9, 0) DEFAULT 0,
    capaciteautofinancement DECIMAL(9, 0) DEFAULT 0,
    variationactifCirculantHaO DECIMAL(9, 0) DEFAULT 0,
    variationStocks DECIMAL(9, 0) DEFAULT 0,
    variationCreances DECIMAL(9, 0) DEFAULT 0,
    variationPassifCirculant DECIMAL(9, 0) DEFAULT 0,
    variationBFR DECIMAL(9, 0) DEFAULT 0,
    FTactiviteOpretationnelles DECIMAL(9, 0) DEFAULT 0,
    decaissementsLiesauxacquisitionsImmobilisationsIncorporelles DECIMAL(9, 0) DEFAULT 0,
    decaissementsLiesauxacquisitionsImmobilisationsCorporelles DECIMAL(9, 0) DEFAULT 0,
    decaissementsLiesauxacquisitionsImmobilisationsFinancieres DECIMAL(9, 0) DEFAULT 0,
    encaissementsLiesauxacquisitionsImmobilisationsIncorpEtCorp DECIMAL(9, 0) DEFAULT 0,
    encaissementsLiesauxacquisitionsImmobilisationsFinancieres DECIMAL(9, 0) DEFAULT 0,
    FTactiviteInvestissement DECIMAL(9, 0) DEFAULT 0,
    augmentationduCapitalParapportsNouveaux DECIMAL(9, 0) DEFAULT 0,
    subventionexploitation DECIMAL(9, 0) DEFAULT 0,
    prelèvementSurLeCapital DECIMAL(9, 0) DEFAULT 0,
    dividendesVerses DECIMAL(9, 0) DEFAULT 0,
    FluxdeTresorerieProvenantdesCapitauxPropres DECIMAL(9, 0) DEFAULT 0,
    emprunts DECIMAL(9, 0) DEFAULT 0,
    autresdettesFinancières DECIMAL(9, 0) DEFAULT 0,
    remboursementempruntsetautresdettesFinanciers DECIMAL(9, 0) DEFAULT 0,
    FluxdeTresorerieProvenantdesCapitauxetrangers DECIMAL(9, 0) DEFAULT 0,
    FTactiviteFinancement DECIMAL(9, 0) DEFAULT 0,
    variationdeTresorerieNette DECIMAL(9, 0) DEFAULT 0,
    tresorerieFinale DECIMAL(9, 0) DEFAULT 0
);

INSERT INTO bilan VALUES(1, 2015, 13, 31137, 565288, 141977, 0, 738416, 15645, 0, 0, 114983, 77995, 208623, 266027, 1213066, 50000, 380803, 0, 838, 193259, 0, 624901, 67340, 692241, 225, 2191, 53404, 55820, 0, 0, 195411, 0, 0, 231727, 427138, 37876, 1213066);
INSERT INTO bilan VALUES(2, 2016, 1200, 77558, 595046, 225046, 0, 929340, 16143, 0, 0, 128217, 68911, 213271, 248690, 1391301, 50000, 410970, 0, 5699, 186331, 0, 641329, 69799, 711128, 673, 1923, 59225, 61821, 0, 0, 188326, 0, 0, 233351, 421676, 196676, 1391301);
INSERT INTO bilan VALUES(3, 2017, 0, 296606, 625255, 155950, 0, 1104599, 14238, 0, 275081, 121237, 153844, 289319, 231399, 1625257, 50000, 407353, 0, -3688, 171801, 0, 625466, 89752, 715218, 661, 158329, 61020, 220010, 0, 0, 273017, 0, 0, 270017, 543072, 146956, 1625257);
INSERT INTO bilan VALUES(4, 2018, 0, 287573, 706798, 163352, 0, 1157722, 13175, 0, 285054, 129735, 155319, 298212, 317439, 1773373, 50000, 403276, 0, 819, 172467, 0, 626561, 90865, 717426, 649, 190053, 72293, 262995, 0, 0, 264233, 0, 0, 304730, 568963, 223989, 1773373);
INSERT INTO bilan VALUES(5, 2019, 0, 323538, 759475, 163970, 0, 1246983, 14338, 0, 281061, 123228, 157833, 295399, 352815, 1895197, 50000, 403562, 0, -3063, 197970, 0, 618470, 95950, 714420, 541, 234087, 72106, 306734, 0, 0, 289355, 0, 0, 378273, 667628, 206415, 1895197);

INSERT INTO compteResultat VALUES(1, 2015, 863291, 863291, 0, 3426, 23926, 890642, 52334, 308334, 360668, 529974, 74119, 455856, 138736, 10671, 327790, 11522, 8510, 0, 330801, 0, 0, -1811, 328911, 110105, 2203, 221089, 0, 221089, 27829, 193259);
INSERT INTO compteResultat VALUES(2, 2016, 905036, 905036, 0, 3877, 28582, 937495, 53420, 357851, 411271, 526224, 83449, 442775, 131426, 11809, 323158, 9879, 20305, 0, 312732, 0, 0, 3648, 316379, 101655, 1156, 215880, 0, 215880, 29549, 186331);
INSERT INTO compteResultat VALUES(3, 2017, 972905, 972905, 0, 4687, 21602, 999194, 61746, 390339, 452085, 547109, 94069, 453040, 161192, 15088, 306936, 10312, 18962, 0, 298285, 0, 0, -1662, 296624, 93502, -1659, 201463, 0, 201463, 29662, 171801);
INSERT INTO compteResultat VALUES(4, 2018, 1021956, 1021956, 0, 2040, 37175, 1061170, 63338, 416938, 480276, 580895, 108417, 472477, 168955, 8764, 312286, 11236, 24753, 0, 298769, 0, 0, -3380, 295390, 95567, 2474, 202297, -46, 202251, 29784, 172467);
INSERT INTO compteResultat VALUES(5, 2019, 1086756, 1086756, 0, 0, 31045, 1117801, 63335, 354688, 0, 599415, 118325, 481090, 182825, 8827, 316748, 8827, 33366, -24539, 292209, 10618, 8128, 2490, 294699, 100133, 2469, 197036, -264, 196771, 28801, 167970);

INSERT fluxTresorerie VALUES (1, 2015, 542, 546, 49486, 24, 54984, 13546, 2132, 156151, 31516, 128217, 68911, 213271, 248690, 1391301, 50000, 564984 ,54654, 28582, 937495, 53420, 357851, 411271, 165485, 8789, 3695, 52014);
INSERT fluxTresorerie VALUES (2, 2016, 542, 546, 49486, 24, 54984, 13546, 2132, 156151, 31516, 128217, 68911, 213271, 248690, 1391301, 50000, 564984 ,54654, 28582, 937495, 53420, 357851, 411271, 165485, 8789, 3695, 52014);
INSERT fluxTresorerie VALUES (3, 2017, 542, 546, 49486, 24, 54984, 13546, 2132, 156151, 31516, 128217, 68911, 213271, 248690, 1391301, 50000, 564984 ,54654, 28582, 937495, 53420, 357851, 411271, 165485, 8789, 3695, 52014);
INSERT fluxTresorerie VALUES (4, 2018, 542, 546, 49486, 24, 54984, 13546, 2132, 156151, 31516, 128217, 68911, 213271, 248690, 1391301, 50000, 564984 ,54654, 28582, 937495, 53420, 357851, 411271, 165485, 8789, 3695, 52014);
INSERT fluxTresorerie VALUES (5, 2019, 542, 546, 49486, 24, 54984, 13546, 2132, 156151, 31516, 128217, 68911, 213271, 248690, 1391301, 50000, 564984 ,54654, 28582, 937495, 53420, 357851, 411271, 165485, 8789, 3695, 52014);