import mysql.connector

my_db =  mysql.connector.connect(host="localhost", user="root", password="", database="etatfinancier")
my_cursor = my_db.cursor()

class CompteResulat:
    def __init__(self) -> None:
        pass

    def getCompteResultat(self, year):
        return [self.getMargeCommericiale(year), self.getChiffreDAffaires(year), self.getProductionStockee(year), self.getProductionImmobilisee(year), self.getAutresProduits(year), self.getProductionExercice(year), self.getAchatsConsommes(year), self.getServicesExterieurs(year), self.getConsommationExercice(year), self.getValeurAjoutee(year), self.getChargesPersonnel(year), self.getExcedentBruteDExploitation(year), self.getDotationsAuxAmortissements(year), self.getReprisesDeProvisions(year), self.getResultatDExploitation(year), self.getProduitsFinanciers(year), self.getChargesFinancieres(year), self.getResultatFinanciers(year), self.getResultatDesActivitesOrdinaires(year), self.getProduitsHOA(year), self.getChargesHAO(year), self.getResultatHOA(year), self.getResultatAvantsImpots(year), self.getImpotsResultat(year), self.getImpotsDifferes(year), self.getResultatNetDesEntreprisesdefegrees(year), self.getPartMiseEnEquivalence(year), self.getResultatNetConsolide(year), self.getPartDesMinoritaires(year), self.getPartEntreprise(year)]

    def getPredictedCompteResultat(self, y):
        return [self.predictMargeCommericiale(y), self.predictChiffreDAffaires(y), self.predictProductionStockee(y), self.predictProductionImmobilisee(y), self.predictAutresProduits(y), self.predictProductionExercice(y), self.predictAchatsConsommes(y), self.predictServicesExterieurs(y), self.predictConsommationExercice(y), self.predictValeurAjoutee(y), self.predictChargesPersonnel(y), self.predictExcedentBruteDExploitation(y), self.predictDotationsAuxAmortissements(y), self.predictReprisesDeProvisions(y), self.predictResultatDExploitation(y), self.predictProduitsFinanciers(y), self.predictChargesFinancieres(y), self.predictResultatFinanciers(y), self.predictResultatDesActivitesOrdinaires(y), self.predictProduitsHOA(y), self.predictChargesHAO(y), self.predictResultatHOA(y), self.predictResultatAvantsImpots(y), self.predictImpotsResultat(y), self.predictImpotsDifferes(y), self.predictResultatNetDesEntreprisesIntegrees(y), self.predictPartMiseEnEquivalence(y), self.predictResultatNetConsolide(y), self.predictPartDesMinoritaires(y), self.predictPartEntreprise(y)]

    def analyseVerticale(self, year):
        av = []
        cr = self.getCompteResultat(year)

        for i in range(len(cr)):
            av.append(cr[i] / cr[1])

        return av

    def analyseHorizontale(self, year):
        ah = []
        crc = self.getCompteResultat(year)
        crp = self.getCompteResultat(year-1)

        for i in range(len(crp)):
            ah.append(crc[i] / crp[i] - 1.0)

        return ah

    def predictAnalyseVerticale(self, y):
        av = []
        cr = self.getPredictedCompteResultat(y)

        for i in range(len(cr)):
            av.append(cr[i] / cr[1])

        return av

    def predictAnalyseHorizontale(self, y):
        ah = []
        crc = self.getPredictedCompteResultat(y)
        crp = self.getPredictedCompteResultat(y-1)

        for i in range(len(crp)):
            ah.append(crc[i] / crp[i] - 1.0)

        return ah

    # -----------GETTER-------------
    def getMargeCommericiale(self, year):
        QUERY = "SELECT margeCommerciale FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getChiffreDAffaires(self, year):
        QUERY = "SELECT chiffreDAffaires FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getProductionStockee(self, year):
        QUERY = "SELECT productionStockee FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getProductionImmobilisee(self, year):
        QUERY = "SELECT productionImmobilisee FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getAutresProduits(self, year):
        QUERY = "SELECT autresProduits FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getProductionExercice(self, year):
        QUERY = "SELECT productionExercice FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getAchatsConsommes(self, year):
        QUERY = "SELECT achatsConsommes FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getServicesExterieurs(self, year):
        QUERY = "SELECT servicesExterieurs FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getConsommationExercice(self, year):
        QUERY = "SELECT consommationExercice FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getValeurAjoutee(self, year):
        QUERY = "SELECT valeurAjoutee FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getChargesPersonnel(self, year):
        QUERY = "SELECT chargesPersonnel FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getExcedentBruteDExploitation(self, year):
        QUERY = "SELECT excedentBruteDExploitation FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getDotationsAuxAmortissements(self, year):
        QUERY = "SELECT dotationsAuxAmortissements FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getReprisesDeProvisions(self, year):
        QUERY = "SELECT reprisesDeProvisions FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getResultatDExploitation(self, year):
        QUERY = "SELECT resultatDExploitation FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getProduitsFinanciers(self, year):
        QUERY = "SELECT produitsFinanciers FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getChargesFinancieres(self, year):
        QUERY = "SELECT chargesFinancieres FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getResultatFinanciers(self, year):
        QUERY = "SELECT resultatFinanciers FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getResultatDesActivitesOrdinaires(self, year):
        QUERY = "SELECT resultatDesActivitesOrdinaires FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getProduitsHOA(self, year):
        QUERY = "SELECT produitsHOA FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getChargesHAO(self, year):
        QUERY = "SELECT chargesHAO FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getResultatHOA(self, year):
        QUERY = "SELECT resultatHOA FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getResultatAvantsImpots(self, year):
        QUERY = "SELECT resultatAvantsImpots FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getImpotsResultat(self, year):
        QUERY = "SELECT impotsResultat FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getImpotsDifferes(self, year):
        QUERY = "SELECT impotsDifferes FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getResultatNetDesEntreprisesdefegrees(self, year):
        QUERY = "SELECT resultatNetDesEntreprisesIntegrees FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getPartMiseEnEquivalence(self, year):
        QUERY = "SELECT partMiseEnEquivalence FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getResultatNetConsolide(self, year):
        QUERY = "SELECT resultatNetConsolide FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getPartDesMinoritaires(self, year):
        QUERY = "SELECT partDesMinoritaires FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]
        
    def getPartEntreprise(self, year):  
        QUERY = "SELECT partEntreprise FROM compteResultat WHERE year = " + str(year)
        my_cursor.execute(QUERY)

        results = my_cursor.fetchone()

        if not results:
            return -1
        
        return results[0]

    # -----------SETTER-------------
    def setMargeCommericiale(self, val, year):
        self.margeCommerciale = val
        if self.margeCommerciale == val:
            
            UPDATE = "UPDATE compteResultat SET margeCommerciale = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setChiffreDAffaires(self, val, year):
        self.chiffreDAffaires = val
        if self.chiffreDAffaires == val:
            
            UPDATE = "UPDATE compteResultat SET chiffreDAffaires = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setProductionStockee(self, val, year):
        self.productionStockee = val
        if self.productionStockee == val:
            
            UPDATE = "UPDATE compteResultat SET productionStockee = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setProductionImmobilisee(self, val, year):
        self.productionImmobilisee = val
        if self.productionImmobilisee == val:
            
            UPDATE = "UPDATE compteResultat SET productionImmobilisee = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setAutresProduits(self, val, year):
        self.autresProduits = val
        if self.autresProduits == val:
            
            UPDATE = "UPDATE compteResultat SET autresProduits = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setProductionExercice(self, val, year):
        self.productionExercice = val
        if self.productionExercice == val:
            
            UPDATE = "UPDATE compteResultat SET productionExercice = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setAchatsConsommes(self, val, year):
        self.achatsConsommes = val
        if self.achatsConsommes == val:
            
            UPDATE = "UPDATE compteResultat SET achatsConsommes = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setServicesExterieurs(self, val, year):
        self.servicesExterieurs = val
        if self.servicesExterieurs == val:
            
            UPDATE = "UPDATE compteResultat SET servicesExterieurs = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setConsommationExercice(self, val, year):
        self.consommationExercice = val
        if self.consommationExercice == val:
            
            UPDATE = "UPDATE compteResultat SET consommationExercice = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setValeurAjoutee(self, val, year):
        self.valeurAjoutee = val
        if self.valeurAjoutee == val:
            
            UPDATE = "UPDATE compteResultat SET valeurAjoutee = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setChargesPersonnel(self, val, year):
        self.chargesPersonnel = val
        if self.chargesPersonnel == val:
            
            UPDATE = "UPDATE compteResultat SET chargesPersonnel = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setExcedentBruteDExploitation(self, val, year):
        self.excedentBruteDExploitation = val
        if self.excedentBruteDExploitation == val:
            
            UPDATE = "UPDATE compteResultat SET excedentBruteDExploitation = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setDotationsAuxAmortissements(self, val, year):
        self.dotationsAuxAmortissements = val
        if self.dotationsAuxAmortissements == val:
            
            UPDATE = "UPDATE compteResultat SET dotationsAuxAmortissements = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setReprisesDeProvisions(self, val, year):
        self.reprisesDeProvisions = val
        if self.reprisesDeProvisions == val:
            
            UPDATE = "UPDATE compteResultat SET reprisesDeProvisions = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setResultatDExploitation(self, val, year):
        self.resultatDExploitation = val
        if self.resultatDExploitation == val:
            
            UPDATE = "UPDATE compteResultat SET resultatDExploitation = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setProduitsFinanciers(self, val, year):
        self.produitsFinanciers = val
        if self.produitsFinanciers == val:
            
            UPDATE = "UPDATE compteResultat SET produitsFinanciers = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setChargesFinancieres(self, val, year):
        self.chargesFinancieres = val
        if self.chargesFinancieres == val:
            
            UPDATE = "UPDATE compteResultat SET chargesFinancieres = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setResultatFinanciers(self, val, year):
        self.resultatFinanciers = val
        if self.resultatFinanciers == val:
            
            UPDATE = "UPDATE compteResultat SET resultatFinanciers = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setResultatDesActivitesOrdinaires(self, val, year):
        self.resultatDesActivitesOrdinaires = val
        if self.resultatDesActivitesOrdinaires == val:
            
            UPDATE = "UPDATE compteResultat SET resultatDesActivitesOrdinaires = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setProduitsHOA(self, val, year):
        self.produitsHOA = val
        if self.produitsHOA == val:
            
            UPDATE = "UPDATE compteResultat SET produitsHOA = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setChargesHAO(self, val, year):
        self.chargesHAO = val
        if self.chargesHAO == val:
            
            UPDATE = "UPDATE compteResultat SET chargesHAO = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setResultatHOA(self, val, year):
        self.resultatHOA = val
        if self.resultatHOA == val:
            
            UPDATE = "UPDATE compteResultat SET resultatHOA = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setResultatAvantsImpots(self, val, year):
        self.resultatAvantsImpots = val
        if self.resultatAvantsImpots == val:
            
            UPDATE = "UPDATE compteResultat SET resultatAvantsImpots = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setImpotsResultat(self, val, year):
        self.impotsResultat = val
        if self.impotsResultat == val:
            
            UPDATE = "UPDATE compteResultat SET impotsResultat = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setImpotsDifferes(self, val, year):
        self.impotsDifferes = val
        if self.impotsDifferes == val:
            
            UPDATE = "UPDATE compteResultat SET impotsDifferes = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setResultatNetDesEntreprisesIntegrees(self, val, year):
        self.resultatNetDesEntreprisesIntegrees = val
        if self.resultatNetDesEntreprisesIntegrees == val:
            
            UPDATE = "UPDATE compteResultat SET resultatNetDesEntreprisesIntegrees = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setPartMiseEnEquivalence(self, val, year):
        self.partMiseEnEquivalence = val
        if self.partMiseEnEquivalence == val:
            
            UPDATE = "UPDATE compteResultat SET partMiseEnEquivalence = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setResultatNetConsolide(self, val, year):
        self.resultatNetConsolide = val
        if self.resultatNetConsolide == val:
            
            UPDATE = "UPDATE compteResultat SET resultatNetConsolide = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setPartDesMinoritaires(self, val, year):
        self.partDesMinoritaires = val
        if self.partDesMinoritaires == val:
            
            UPDATE = "UPDATE compteResultat SET partDesMinoritaires = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    def setPartEntreprise(self, val, year):
        self.partEntreprise = val
        if self.partEntreprise == val:
            
            UPDATE = "UPDATE compteResultat SET partEntreprise = '" + str(val) + "' WHERE year = " + str(year)
            my_cursor.execute(UPDATE)

            my_db.commit()
            
            return True
        else:
            return False

    # -----------PREDICT------------
    def predictMargeCommericiale(self, y):
        COEFFICIENT = 48578.23616601
        INTERCEPT = -97034585.22134385

        return COEFFICIENT * y + INTERCEPT

    def predictChiffreDAffaires(self, y):
        COEFFICIENT = 48578.23616601
        INTERCEPT = -97034585.22134385

        return COEFFICIENT * y + INTERCEPT

    def predictProductionStockee(self, y):
        COEFFICIENT = 0
        INTERCEPT = 0

        return COEFFICIENT * y + INTERCEPT

    def predictProductionImmobilisee(self, y):
        COEFFICIENT = 265.32167832
        INTERCEPT = -531600.21095571

        return COEFFICIENT * y + INTERCEPT

    def predictAutresProduits(self, y):
        COEFFICIENT = 1353.07905138
        INTERCEPT = -2700531.64822134

        return COEFFICIENT * y + INTERCEPT

    def predictProductionExercice(self, y):
        COEFFICIENT = 50094.69071146
        INTERCEPT = -1.00062031e+08

        return COEFFICIENT * y + INTERCEPT

    def predictAchatsConsommes(self, y):
        COEFFICIENT = 3039.99505929
        INTERCEPT = -6072372.64426877

        return COEFFICIENT * y + INTERCEPT

    def predictServicesExterieurs(self, y):
        COEFFICIENT0 = 0.00000000e+00
        COEFFICIENT1 = -2.62146296e+06
        COEFFICIENT2 = 6.57765810e+02
        INTERCEPT = 2.61189149e+09
        
        return COEFFICIENT0 + (COEFFICIENT1 * y) + (COEFFICIENT2 * pow(y, 2)) + INTERCEPT

    def predictConsommationExercice(self, y):
        COEFFICIENT0 = 0.00000000e+00
        COEFFICIENT1 = -2.81882648e+06
        COEFFICIENT2 = 7.07686194e+02
        INTERCEPT = 2.8069453e+09
        
        return COEFFICIENT0 + (COEFFICIENT1 * y) + (COEFFICIENT2 * pow(y, 2)) + INTERCEPT

    def predictValeurAjoutee(self, y):
        COEFFICIENT = 26860.63339921
        INTERCEPT = -53616902.99604743

        return COEFFICIENT * y + INTERCEPT

    def predictChargesPersonnel(self, y):
        COEFFICIENT0 = 0.00000000e+00
        COEFFICIENT1 =  -4.54209498e+05
        COEFFICIENT2 = 1.14245737e+02
        INTERCEPT = 4.51452482e+08
        
        return COEFFICIENT0 + (COEFFICIENT1 * y) + (COEFFICIENT2 * pow(y, 2)) + INTERCEPT

    def predictExcedentBruteDExploitation(self, y):
        COEFFICIENT = 22258.19762846
        INTERCEPT = -44426171.66403161

        return COEFFICIENT * y + INTERCEPT

    def predictDotationsAuxAmortissements(self, y):
        COEFFICIENT = 7637.43083004
        INTERCEPT = -15251187.8458498

        return COEFFICIENT * y + INTERCEPT

    def predictReprisesDeProvisions(self, y):
        COEFFICIENT0 = 0.00000000e+00
        COEFFICIENT1 =  -9.83186008e+04
        COEFFICIENT2 = 2.45858554e+01
        INTERCEPT = 98296988.16138238
        
        return COEFFICIENT0 + (COEFFICIENT1 * y) + (COEFFICIENT2 * pow(y, 2)) + INTERCEPT

    def predictResultatDExploitation(self, y):
        COEFFICIENT = 15135.17094862
        INTERCEPT = -30201391.35177866

        return COEFFICIENT * y + INTERCEPT

    def predictProduitsFinanciers(self, y):
        COEFFICIENT = 402.1215415
        INTERCEPT = -800542.7944664

        return COEFFICIENT * y + INTERCEPT

    def predictChargesFinancieres(self, y):
        COEFFICIENT0 = 0.00000000e+00
        COEFFICIENT1 =  -2.77371248e+05
        COEFFICIENT2 = 6.92987013e+01
        INTERCEPT = 2.77550775e+08
        
        return COEFFICIENT0 + (COEFFICIENT1 * y) + (COEFFICIENT2 * pow(y, 2)) + INTERCEPT

    def predictResultatFinanciers(self, y):
        COEFFICIENT0 = 0.00000000e+00
        COEFFICIENT1 =  2.95998776e+05
        COEFFICIENT2 = -7.38369001e+01
        INTERCEPT = -2.96649426e+08
        
        return COEFFICIENT0 + (COEFFICIENT1 * y) + (COEFFICIENT2 * pow(y, 2)) + INTERCEPT

    def predictResultatDesActivitesOrdinaires(self, y):
        COEFFICIENT = 14615.61363636
        INTERCEPT = -29160401.79051382

        return COEFFICIENT * y + INTERCEPT

    def predictProduitsHOA(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictChargesHAO(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictResultatHOA(self, y):
        COEFFICIENT = -90.1986166
        INTERCEPT = 179021.4743083

        return COEFFICIENT * y + INTERCEPT

    def predictResultatAvantsImpots(self, y):
        COEFFICIENT = 14582.17193676
        INTERCEPT = -29093889.72727272

        return COEFFICIENT * y + INTERCEPT

    def predictImpotsResultat(self, y):
        COEFFICIENT0 = 0.00000000e+00
        COEFFICIENT1 =  -4.95807184e+05
        COEFFICIENT2 = 1.24682665e+02
        INTERCEPT = 4.92898544e+08
        
        return COEFFICIENT0 + (COEFFICIENT1 * y) + (COEFFICIENT2 * pow(y, 2)) + INTERCEPT

    def predictImpotsDifferes(self, y):
        COEFFICIENT = 95.0770751
        INTERCEPT = -189882.02766798

        return COEFFICIENT * y + INTERCEPT

    def predictResultatNetDesEntreprisesIntegrees(self, y):
        COEFFICIENT0 = 0.00000000e+00
        COEFFICIENT1 =  1.29820493e+06
        COEFFICIENT2 = -3.20870243e+02
        INTERCEPT = -1.31287663e+09
        
        return COEFFICIENT0 + (COEFFICIENT1 * y) + (COEFFICIENT2 * pow(y, 2)) + INTERCEPT

    def predictPartMiseEnEquivalence(self, y):
        COEFFICIENT = 0.0
        INTERCEPT = 0.0

        return COEFFICIENT * y + INTERCEPT

    def predictResultatNetConsolide(self, y):
        COEFFICIENT = 9675.72332016
        INTERCEPT =-19293819.81818181

        return COEFFICIENT * y + INTERCEPT

    def predictPartDesMinoritaires(self, y):
        COEFFICIENT = 1641.54743083
        INTERCEPT = -3281048.58893281

        return COEFFICIENT * y + INTERCEPT

    def predictPartEntreprise(self, y):
        COEFFICIENT = 7943.0770751
        INTERCEPT = -15829475.24505929

        return COEFFICIENT * y + INTERCEPT