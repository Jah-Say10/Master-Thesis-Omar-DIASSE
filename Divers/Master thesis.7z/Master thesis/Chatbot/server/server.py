from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import pandas as pd
import numpy as np
import spacy
import joblib
from sklearn.feature_extraction.text import CountVectorizer
from translate import Translator

def translate_text(text, from_lg, to_lg):
    translator = Translator(from_lang=from_lg, to_lang=to_lg)
    translation = translator.translate(text)

    return str(translation)

import sys
sys.path.append("../responses")
from responses import response

nlp = spacy.load("en_core_web_sm")
def preprocess(text):
    doc = nlp(text)

    filter_word = []

    for token in doc:
        filter_word.append(token.lemma_)

    return " ".join(filter_word)

df = pd.read_csv("../intents recognition models/intents_data.csv")

text = df.Text.apply(preprocess)
intent = df.Intent.map({
    "small_talk": 0,
    "thanks": 1, 
    "help": 2,     
    "predict": 3,
    "get": 4,
    "set": 5,
    "calculate": 6,
    "definition": 7,
    "quit": 8
})

df1 = pd.concat([text, intent], axis="columns")

count_vectorizer = CountVectorizer(ngram_range=(1, 2))

count_vectorizer.fit_transform(df1.Text.values)

model = joblib.load("intent_classification_model")

confuse_vectorize = count_vectorizer.transform([preprocess("ddddddddddddd")]).toarray()
confuse_proba = model.predict_proba(confuse_vectorize)

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def ping():
    return {"hello": "Hello I am alive !!!"}

@app.get("/predict/en/{question}")
def predict(question):
        
    print("en")
    print(question)
    question_vectorize = count_vectorizer.transform([preprocess(question)]).toarray()
    intent_classe = model.predict(question_vectorize)
    intents_proba = model.predict_proba(question_vectorize)
    
    print(intents_proba)

    intent_label = ""

    match intent_classe[0]:
        case 0:
            intent_label = "small_talk"
        case 1:
            intent_label = "thanks"
        case 2:
            intent_label = "help"
        case 3:
            intent_label = "predict"
        case 4:
            intent_label = "get"
        case 5:
            intent_label = "set"
        case 6:
            intent_label = "calculate"
        case 7:
            intent_label = "definition"
        case 8:
            intent_label = "quit"

    if np.array_equiv(intents_proba, confuse_proba):
        intent_label = "confuse"

    print(intent_label)

    responses = response(str(question).lower(), intent_label)
    print(responses)

    json = {
        "intent": float(intent_classe[0]),
        "response": responses,
        "proba": {
            "small_talk": float(intents_proba[0][0]),
            "thanks": float(intents_proba[0][1]),
            "help": float(intents_proba[0][2]),
            "predict": float(intents_proba[0][3]),
            "get": float(intents_proba[0][4]),
            "set": float(intents_proba[0][5]),
            "calculate": float(intents_proba[0][6]),
            "definition": float(intents_proba[0][7]),
            "quit": float(intents_proba[0][8]),
        }
    }

    return json

# ---------------------------------

@app.get("/predict/fr/{question}")
def predict(question):

    print("fr")
    question_translated = translate_text(question, "fr", "en")
    print(question_translated)

    question_vectorize = count_vectorizer.transform([preprocess(question_translated)]).toarray()
    intent_classe = model.predict(question_vectorize)
    intents_proba = model.predict_proba(question_vectorize)
    
    print(intent_classe)
    print(intents_proba)

    intent_label = ""

    match intent_classe[0]:
        case 0:
            intent_label = "small_talk"
        case 1:
            intent_label = "thanks"
        case 2:
            intent_label = "help"
        case 3:
            intent_label = "predict"
        case 4:
            intent_label = "get"
        case 5:
            intent_label = "set"
        case 6:
            intent_label = "calculate"
        case 7:
            intent_label = "definition"
        case 8:
            intent_label = "quit"

    if np.array_equiv(intents_proba, confuse_proba):
        intent_label = "confuse"
        
    print(intent_label)

    responses = response(str(question_translated).lower(), intent_label)

    response_translated = translate_text(responses, "en", "fr")
    print(response_translated)

    json = {
        "intent": float(intent_classe[0]),
        "response": response_translated,
        "proba": {
            "small_talk": float(intents_proba[0][0]),
            "thanks": float(intents_proba[0][1]),
            "help": float(intents_proba[0][2]),
            "predict": float(intents_proba[0][3]),
            "get": float(intents_proba[0][4]),
            "set": float(intents_proba[0][5]),
            "calculate": float(intents_proba[0][6]),
            "definition": float(intents_proba[0][7]),
            "quit": float(intents_proba[0][8]),
        }
    }

    return json

if __name__ == "__main__":
    uvicorn.run(app, host="localhost", port=8000)