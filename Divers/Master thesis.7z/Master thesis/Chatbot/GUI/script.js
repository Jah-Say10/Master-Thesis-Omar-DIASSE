// let url = "http://localhost:8000/predict/fr/"
let url = "http://localhost:8000/question/"

function query()
{
    let question = $("#question").val()
    let discussionElement = "<p class='ques'> <img src='user.png' width='30' height='30' alt=''> " + question + "</p>"
    $("#discussion").append(discussionElement)
    $("#question").val("")

    console.log(question)

    jquery((url+question), "GET", question)
}

function jquery(url, method, question)
{
    $.ajax(
    {
        url: url,
        type: method,
        
        success: function(result)
        {
            console.log(result)

            let discussionElement = "<p class='resp'> <img src='chat.png' width='30' height='30' alt=''> " + result.response + "</p>"

            $("#discussion").append(discussionElement)
        },
        error: function(err)
        {
            console.log(err)

        }
    })
}

window.onload = (e) =>
{
    const btn = $("#btn")
    btn.click(() => 
    {
        query()
    })

    $("#question").keyup((e) =>
    {
        if(e.key === "Enter")
        {
            query()
        }
    })

    const newChat = $("#newChat")
    newChat.click(() => 
    {
        location.reload();
    })

    const enChat = $("#enChat")
    enChat.click(() => 
    {
        // url = "http://localhost:8000/predict/en/"
        url = "http://localhost:8000/question/"
        $("#lg").text("En")
    })

    const frChat = $("#frChat")
    frChat.click(() => 
    {
        // url = "http://localhost:8000/predict/fr/"
        url = "http://localhost:8000/question/"
        $("#lg").text("Fr")
    })
}