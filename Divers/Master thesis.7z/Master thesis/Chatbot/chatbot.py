import random
import math

class Chatbot:
    def __init__(self) -> None:

        self.intents = {
            "greeting": ["hello", "hi", "hey", "yo", "heya", "hey there", "morning", "howdy", "good morning", "good afternoon", "good evening"],
            "small_tack": ["how are you", "how about today", "what it do", "how are things", "it's good to see you", "what's up"],
            "quit": ["thank's, that's it", "see you", "i'm done", "quit"],
            "thanks": ["you are good", "awesome!", "exacty what i need", "thank's you"],

            "predict": ["what will be our turnover in 2025", "predict the turnover in 2025", "i need the turnover of 2025"],
            "get": ["give the turnover", "what is the turnover", "show the turnover"],
            "get_past": ["what was last year turnover", "get turnover for 1 year ago", "i need past turnover"],
            "set": ["change the value of turnover", "i want the turnover to be 2000", "the turnover pass from 2020 to 2000"],

            "definition": ["what is a turnover", "define a turnover", "can you explain what a turnover is"],
            "calculation": ["calculate 1 + 1", "give the resultat of 1 + 1", "add 1 to 1"],
            "impression": ["is our financial statement good", "what do to think about our financial statement", "are we in safe place"],
           
            "about": ["who are you", "i want to know you", "tell me about you"],
            "help": ["i need help", "can you help me", "need some assistance here"]
        }

        self.responses = {
            "greeting": ["Hello", "Hi", "Hey", "Heya", "Hey there", "Howdy"],
            "small_tack": ["I am great", "Today is good", "So far, so good"],
            "quit": ["Thank's you", "Good bye", "See you"],
            "thanks": ["I appreciate it", "I glad to you", "No problem, just doing my job"],

            "predict": ["In 2025, our turnover will be 2050", "Turnover will be 2050 in 2025", "We can expect 2050 of turnover in 2025"],
            "get": ["The turnover is 2020", "Turnover = 2020", "Our current turnover is 2020"],
            "get_past": ["Last year turnover is 1995", "The turnover from last year is 1995", "We had a turnover value of 1995 last year ago"],
            "set": ["Done! new turnover is 2000", "New turnover update to 2000!", "That's it, our need turnover is 2000!"],

            "definition": ["A turnover is the global production sold", "A turnover is quantity times the price", "A turnover is all money from our sold"],
            "calculation": ["1 + 1 = 2", "Result: 1 + 1 = 2", "Calculation: 1 + 1 = 2"],
            "impression": ["Our financials statements are good", "We are in safe zone", "We're doing well"],
           
            "about": ["I'm a chatbot that can help with our finance", "I'm your finance assistant", "I am computer program desing to assit you in your finance"],
            "help": ["How can i help you", "I am all ears :)", "i here to help you, tell me"]
        }

        self.confuses = ["I don't understand", "Come again", "Could you please rephrase that", "Tell that in way that i understand", "I don't get that"]

        self.intents_list = []
        for k in self.intents.keys():
                self.intents_list.append(k)


    def get_intent(self, text):

        for k, v in self.intents.items():
            if text in v:
                return k
            
        return "none"

    def get_entity(self, text):
        pass

    def conversion(self):

        predixe = "Chatbot :"

        while True:
            # Take the user question
            user = input("You     : ")

            # Get the user intent
            intent = self.get_intent(user.lower())

            # If the intent to quit
            if intent == "quit":
                # Generate a random index for random response
                random_index = math.floor(random.random() * len(self.responses["quit"]))
                print(predixe, self.responses["quit"][random_index])
                return
            # If we dont understant the user
            elif intent == "none":
                # Generate a random index for random response
                random_index = math.floor(random.random() * len(self.confuses))
                print(predixe, self.confuses[random_index])

            # Response the user accordingly to the intent
            for i in self.intents_list:
                if i == intent:
                    # Generate a random index for random response
                    random_index = math.floor(random.random() * len(self.responses[intent]))
                    print(predixe, self.responses[i][random_index])
                    break