from langchain_groq import ChatGroq
from langchain_core.prompts import PromptTemplate
import re
import langid

import sys
sys.path.append("../responses")
from responses import response

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def ping():
    return {"hello": "Hello I am alive !!!"}

llm = ChatGroq(
    model="llama-3.3-70b-versatile",
    groq_api_key="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",
    temperature=.7,
)

def rephrase(sentence):

    prompt_extract = PromptTemplate.from_template(
       """Rephrase this sentence in profession way that a chatbot response to a user : '{sentence}'"""
    )
    
    chain_extract = prompt_extract | llm 
    res = chain_extract.invoke(input={'sentence':sentence})
    return res.content

def rephrase_fr(sentence):

    prompt_extract = PromptTemplate.from_template(
       """Reformulez cette phrase d'une manière professionnelle pour qu'un chatbot puisse répondre à un utilisateur en francais: '{sentence}'"""
    )
    
    chain_extract = prompt_extract | llm 
    res = chain_extract.invoke(input={'sentence':sentence})
    return res.content

def get_response(sentence):

    prompt_extract = PromptTemplate.from_template(
       """I am building a chatbot for communication with financial statement for a specific company which have those 9 followings intents :
        - 0 : greeting the Chatbot,
        - 1 : thanking the Chatbot,
        - 2 : asking for help to the Chatbot,
        - 3 : request prediction of a financial statement element to the Chatbot,
        - 4 : request to get current year financial statement element to the Chatbot,
        - 5 : request to set financial statement element in the database to the Chatbot,
        - 6 : asking for a definition for a financial statement element to the Chatbot,
        - 7 : Make a calculation,
        - 8 : tell the Chatbot that user going to leave,
        - 9 : if the user question dont match any of those intent

        I want to mention I develop all function to the above intent to response.
        What I want you to do is to help me identifying the intent of a user of my Chatbot.

        Exemple, what is intent of this sentence : '{sentence}'
        Your response should be as following : number, explanation"""
    )
    
    chain_extract = prompt_extract | llm 
    res = chain_extract.invoke(input={'sentence':sentence})
    return res.content

def get_response_fr(sentence):

    prompt_extract = PromptTemplate.from_template(
       """Je développe un chatbot pour la communication avec les états financiers d'une entreprise spécifique qui a les 9 intentions suivantes :
        - 0 : salutation du Chatbot,
        - 1 : remercier le Chatbot,
        - 2 : demander de l'aide au Chatbot,
        - 3 : demander la prédiction d'un élément des etats financiers au Chatbot,
        - 4 : demande de valeur d'un élément des etats financiers de l'année en cours au Chatbot,
        - 5 : demande la mise a jour d'un élément des etats financiers dans la base de données au Chatbot,
        - 6 : demander une définition d'un élément de bilan au Chatbot,
        - 7 : Faire un calcul,
        - 8 : prévenir le Chatbot que l'utilisateur va partir,
        - 9 : si la question de l'utilisateur ne correspond à aucune de ces intentions

        Je tiens à mentionner que je développe toutes les fonctions selon l'intention de réponse ci-dessus.
        Ce que je veux que vous fassiez, c'est m'aider à identifier l'intention d'un utilisateur de mon Chatbot.

        Exemple, quelle est l'intention de cette phrase : '{sentence}'
        Votre réponse doit être la suivante : numéro, explication"""
    )
    
    chain_extract = prompt_extract | llm 
    res = chain_extract.invoke(input={'sentence':sentence})
    return res.content

def fr(sentence):

    prompt_extract = PromptTemplate.from_template(
       """Return True if this sentence is in French, don't explain please : '{sentence}'"""
    )
    
    chain_extract = prompt_extract | llm 
    res = chain_extract.invoke(input={'sentence':sentence})
    return res.content

def translate(sentence):

    prompt_extract = PromptTemplate.from_template(
       """Translate from french to english, return only the translation don't explain please : '{sentence}'"""
    )
    
    chain_extract = prompt_extract | llm 
    res = chain_extract.invoke(input={'sentence':sentence})
    return res.content

@app.get("/question/{question}")
def intent_handle(question):

    print("-----------------------------")
    resp = ""

    # get language
    # language, _ = langid.classify(question)
    is_fr = ('True' in fr(question) or 'true' in fr(question))
    if is_fr:
        resp = get_response_fr(question)
        print("Fr", fr(question))
    else:
        resp = get_response(question)
        print("En", fr(question))

    match = re.search(r'\b\d\b', resp)
    intent_class = "9"
    if match:
        intent_class = match.group()

    intent_label = ""

    match int(intent_class):
        case 0:
            intent_label = "small_talk"
        case 1:
            intent_label = "thanks"
        case 2:
            intent_label = "help"
        case 3:
            intent_label = "predict"
        case 4:
            intent_label = "get"
        case 5:
            intent_label = "set"
        case 6:
            intent_label = "definition"
        case 7:
            intent_label = "calculate"
        case 8:
            intent_label = "quit"
        case 9:
            intent_label = "confuse"

    print("Question:", question)
    print("Response:", resp)
    print("Intent:", intent_label)
    print("Class:", intent_class)

    if is_fr:
        print("Translate fr:", translate(str(question)))
        responses = response(translate(str(question)).lower(), intent_label) # tranlate question in En
    else:
        responses = response(str(question).lower(), intent_label)

    print("Response (ori):", responses)

    if is_fr:
        responses = rephrase_fr(responses)
    else:
        responses = rephrase(responses)

    print("Response (rep):", responses)

    json = {
        "intent": float(intent_class),
        "response": responses,
        "proba": {
            "small_talk": 0.1,
            "thanks": 0.1,
            "help": 0.1,
            "predict": 0.1,
            "get": 0.1,
            "set": 0.1,
            "calculate": 0.1,
            "definition": 0.1,
            "quit": 0.1,
        }
    }

    return json

if __name__ == "__main__":
    uvicorn.run(app, host="localhost", port=8000)